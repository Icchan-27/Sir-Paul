    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SMC Clinic Dashboard</title>
    <style>
        body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }
        .sidebar {
        width: 200px;
        height: 100vh;
        background-color: #f5f5f5;
        position: fixed;
        left: 0;
        top: 0;
        padding: 20px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }
        .sidebar h2 {
        font-size: 18px;
        color: #333;
        margin-bottom: 20px;
        }
        .sidebar a {
        display: block;
        text-decoration: none;
        color: #333;
        padding: 10px;
        margin-bottom: 5px;
        border-radius: 5px;
        }
        .sidebar a:hover,
        .sidebar a.active {
        background-color: #2c7df7;
        color: white;
        }
        .header {
        background-color: #2c7df7;
        color: white;
        padding: 15px;
        font-size: 20px;
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        z-index: 1;
        }
        .logout-link {
        color: white;
        text-decoration: none;
        position: absolute;
        right: 50px;
        top: 15px;
        font-size: 15px;
        background-color: #1f5edb;
        padding: 5px 10px;
        border-radius: 5px;
        transition: background 0.3s ease;
        }
        .tab {
        margin-left: 260px;
        margin-top: 70px;
        background-color: #2c7df7;
        color: white;
        padding: 10px 20px;
        font-weight: bold;
        display: inline-block;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        box-shadow: 0 -2px 4px rgba(0,0,0,0.1);
        }
        .content {
        margin-left: 260px;
        margin-top: 0;
        background: #fff;
        padding: 20px;
        border-radius: 10px;
        border-top-left-radius: 0px;
        width: calc(100% - 280px);
        max-width: 1200px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        margin-bottom: 20px;
        box-sizing: border-box;
        }
        table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        border: 1px solid #ddd;
        }
        th, td {
        text-align: left;
        padding: 10px;
        border-bottom: 1px solid #ddd;
        border-right: 1px solid #ddd;
        }
        th {
        background-color: #2c7df7;
        color: white;
        }
        td:last-child, th:last-child {
        border-right: none;
        }
        tbody tr:hover {
        background-color: #f1f1f1;
        }
        @media (max-width: 1200px) {
        .content, .tab {
            width: calc(100% - 280px);
        }
        }
        @media (max-width: 1024px) {
        .content, .tab {
            width: calc(100% - 240px);
            margin-left: 240px;
        }
        }
        @media (max-width: 768px) {
        .content, .tab {
            width: calc(100% - 200px);
            margin-left: 200px;
        }
        }
        @media (max-width: 480px) {
        .content, .tab {
            width: calc(100% - 160px);
            margin-left: 160px;
        }
        .header {
            font-size: 16px;
            padding: 8px;
        }
        }
    </style>
    </head>
    <body>
    <div class="sidebar">
        <h2>SMC Clinic</h2>
        <a href="loginDashboard.php">Profile</a>
        <a href="studentClinic.php">Clinic</a>
        <a href="#" class="active">Medicines</a>
    </div>
    <div class="header">
        SMC Clinic Dashboard
        <a href="logout.php" class="logout-link">Log Out</a>
    </div>
    <div class="tab">Medicines</div>
    <div class="content">
        <h3><strong>Available Medicines</strong></h3>
        <table>
        <thead>
            <tr>
            <th>Medicine</th>
            <th>Status</th>
            </tr>
        </thead>
        <tbody id="medicines-body"></tbody>
        </table>
    </div>

    <script>
        function getInventory() {
        return JSON.parse(localStorage.getItem("inventory")) || [];
        }

        function renderMedicines() {
        const body = document.getElementById("medicines-body");
        body.innerHTML = "";
        const inventory = getInventory();
        inventory.forEach(med => {
            const row = document.createElement("tr");
            row.innerHTML = `
            <td>${med.name}</td>
            <td>${med.status}</td>
            `;
            body.appendChild(row);
        });
        }

        window.addEventListener("DOMContentLoaded", renderMedicines);
    </script>
    </body>
    </html>
