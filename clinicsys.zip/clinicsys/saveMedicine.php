<?php
session_start();
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patientName = $_POST['patient_name'];  
    $patientId = $_POST['patient_id'];
    $medicineName = $_POST['medicine_name']; 
    $quantity = (int)$_POST['medicine_qty']; 
    $reason = $_POST['reason'];          

    // 1. Validate patient
    $getPatient = $conn->prepare("SELECT * FROM patient WHERE id_number = ?");
    $getPatient->bind_param("s", $patientId);
    $getPatient->execute();
    $patientResult = $getPatient->get_result();

    if ($patientResult->num_rows > 0) {
        // 2. Find medicine in inventory
        $getMedicine = $conn->prepare("SELECT inventory_id, medicine_id, quantity FROM inventory WHERE medicine_id = ?");
        $getMedicine->bind_param("i", $medicineId);
        $getMedicine->execute();
        $medicineResult = $getMedicine->get_result();

        if ($medicineResult->num_rows > 0) {
            $medicine = $medicineResult->fetch_assoc();
            $inventoryId = $medicine['inventory_id'];
            $stockRemaining = $medicine['quantity'];

            if ($stockRemaining >= $quantity) {
                // 3. Insert into medicine table
                $insertMedicine = $conn->prepare("INSERT INTO medicine (medicine_id, patient_id, quantity, reason) VALUES (?, ?, ?, ?)");
                $insertMedicine->bind_param("isis", $medicineId, $patientId, $quantity, $reason);
                $insertMedicine->execute();

                // 4. Update inventory
                $newStockRemaining = $stockRemaining - $quantity;
                $newStatus = ($newStockRemaining > 0) ? 'Available' : 'Not Available';

                $updateInventory = $conn->prepare("UPDATE inventory SET quantity = ?, status = ? WHERE inventory_id = ?");
                $updateInventory->bind_param("isi", $newStockRemaining, $newStatus, $inventoryId);
                $updateInventory->execute();

                echo "<script>alert('Medicine request saved successfully!'); window.location.href='nurseManage.php';</script>";
            } else {
                echo "<script>alert('Not enough stock remaining.'); window.location.href='nurseManage.php';</script>";
            }
        } else {
            echo "<script>alert('Medicine not found in inventory.'); window.location.href='nurseManage.php';</script>";
        }
    } else {
        echo "<script>alert('Patient not found!'); window.location.href='nurseManage.php';</script>";
    }
}
?>
