<?php
session_start();
include 'connect.php';

// Get login inputs safely
$id_number = $_POST['id_number'] ?? '';
$password = $_POST['password'] ?? '';

// First check in nurse table (admin login)
$stmt_nurse = $conn->prepare("SELECT * FROM nurse WHERE id_number = ? AND password = ?");
$stmt_nurse->bind_param("ss", $id_number, $password);
$stmt_nurse->execute();
$nurse_result = $stmt_nurse->get_result();

// Then check in patient table (user login)
$stmt_patient = $conn->prepare("SELECT * FROM patient WHERE id_number = ? AND password = ?");
$stmt_patient->bind_param("ss", $id_number, $password);
$stmt_patient->execute();
$patient_result = $stmt_patient->get_result();

if ($nurse_result->num_rows > 0) {
    // Found in nurse table → Admin
    $_SESSION['admin'] = true;
    $_SESSION['username'] = $id_number;
    header("Location: nurseDashBoard.php");
    exit();
} elseif ($patient_result->num_rows > 0) {
    // Found in patient table → User
    $_SESSION['user'] = true;
    $_SESSION['username'] = $id_number;
    header("Location: loginDashboard.php");
    exit();
} else {
    // Invalid credentials
    echo "<script>
            alert('Invalid ID Number or Password!');
            window.location.href='Loginpage.php';
          </script>";
}

// Close statements and connection
$stmt_nurse->close();
$stmt_patient->close();
$conn->close();
?>
