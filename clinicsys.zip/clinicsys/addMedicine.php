<?php
include 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $medicine_name = $_POST['medicine_name'];
    $quantity = $_POST['quantity'];

    // Check if the medicine already exists in the inventory
    $query = "SELECT * FROM inventory WHERE medicine_name = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $medicine_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update existing stock
        $row = $result->fetch_assoc();
        $new_stockremaining = $row['stockremaining'] + $quantity;
        $new_totalstock = $row['totalstock'] + $quantity;

        $update_query = "UPDATE inventory SET stockremaining = ?, totalstock = ? WHERE medicine_name = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param('iis', $new_stockremaining, $new_totalstock, $medicine_name);
        $update_stmt->execute();
    } else {
        // Insert new medicine
        $insert_query = "INSERT INTO inventory (medicine_name, stockremaining, totalstock, status) VALUES (?, ?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_query);
        $status = 'Available';
        $insert_stmt->bind_param('siis', $medicine_name, $quantity, $quantity, $status);
        $insert_stmt->execute();
    }

    // ✅ Redirect back to nurseInventory.php
    header("Location: nurseInventory.php");
    exit();
}
?>
