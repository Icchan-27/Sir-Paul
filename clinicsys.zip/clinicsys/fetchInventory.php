<?php
include 'connect.php';

$query = "SELECT * FROM inventory";
$result = $conn->query($query);

$inventory = [];
while ($row = $result->fetch_assoc()) {
    $inventory[] = $row;
}

echo json_encode($inventory);
?>
