<?php
include('connect.php');
session_start();

$sql = "SELECT * FROM appointments INNER JOIN patient ON appointments.patient_id = patient.patient_id WHERE appointments.status = 'Rejected' ORDER BY appointments.appointmentDate ASC, appointments.appointmentTime ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SMC Clinic Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .sidebar {
            width: 200px;
            height: 100vh;
            background-color: #f5f5f5;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar h2 {
            font-size: 18px;
            color: #333;
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            text-decoration: none;
            color: #333;
            padding: 10px;
            margin-bottom: 5px;
            border-radius: 5px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #2c7df7;
            color: white;
        }

        .header {
            background-color: #2c7df7;
            color: white;
            padding: 15px;
            font-size: 20px;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            z-index: 1;
        }

        .logout-link {
            color: white;
            text-decoration: none;
            position: absolute;
            right: 50px;
            top: 15px;
            font-size: 15px;
            background-color: #1f5edb;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .main-content {
            margin-left: 220px;
            padding: 100px 20px 20px 20px;
        }

        .profile {
            display: flex;
            align-items: center;
            background-color: #dce6ff;
            padding: 15px;
            border-radius: 10px;
            width: 90%;
            margin: 0 auto;
        }

        .tabs {
            margin-top: 20px;
            display: flex;
            border-bottom: 2px solid #2c7df7;
            margin-left: 20px;
        }

        .tab {
            padding: 10px 20px;
            cursor: pointer;
            text-decoration: none;
            color: #333;
        }

        .tab:hover,
        .tab.active {
            background-color: #2c7df7;
            color: white;
            border-radius: 5px 5px 0 0;
        }

        .content {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-top: -2px;
            margin-left: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #2c7df7;
            color: white;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>SMC Clinic</h2>
        <a href="#" class="active">Appointments</a>
        <a href="nurseClinic.php">Clinic</a>
        <a href="nurseInventory.php">Inventory</a>
        <a href="#">Patient List</a>
    </div>

    <div class="header">
        SMC Clinic Dashboard
        <a href="logout.php" class="logout-link">Log Out</a>
    </div>

    <div class="main-content">
        <div class="profile">
            <h2><?php echo $_SESSION['name']; ?></h2>
        </div>

        <div class="tabs">
            <a href="nurseDashBoard.php" class="tab">Pending</a>
            <a href="nurseAppointed.php" class="tab">Appointed</a>
            <a href="nurseDone.php" class="tab">Done</a>
            <a href="#" class="tab active">Rejected</a>
        </div>

        <div class="content">
            <table>
                <tr>
                    <th>Patient Name</th>
                    <th>Reason</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
                <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['firstName']) . " " . htmlspecialchars($row['lastName']) ."</td>";
                            echo "<td>" . htmlspecialchars($row['Reason']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['appointmentDate']) . " at " . htmlspecialchars($row['appointmentTime']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['Status']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No done appointments to show.</td></tr>";
                    }

                    $conn->close();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
