<?php
// Include the database connection
include 'connect.php';

// Debugging: Check incoming POST data
error_log("POST Data: " . print_r($_POST, true)); // Log POST data for debugging

// Check if POST data exists
if (isset($_POST['patientId']) && isset($_POST['medicine']) && isset($_POST['quantity']) && isset($_POST['reason'])) {
    $patientId = $_POST['patientId'];
    $medicine = $_POST['medicine'];
    $quantity = $_POST['quantity'];
    $reason = $_POST['reason'];

    // Sanitize input
    $patientId = intval($patientId); // Ensure it's an integer
    $medicine = htmlspecialchars($medicine);
    $quantity = intval($quantity);
    $reason = htmlspecialchars($reason);

    // Prepare and execute the query to insert data into medicine table
    $query = "INSERT INTO medicine (patient_id, medicine_name, quantity, reason) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt === false) {
        // Query preparation failed
        error_log("MySQL prepare failed: " . $conn->error); // Log error
        echo json_encode(['status' => 'error', 'message' => 'MySQL prepare failed: ' . $conn->error]);
        exit();
    }

    // Bind parameters and execute
    $stmt->bind_param('isds', $patientId, $medicine, $quantity, $reason);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Record submitted successfully.']);
    } else {
        // Log the actual SQL error message if execution fails
        error_log("Execute failed: " . $stmt->error);
        echo json_encode(['status' => 'error', 'message' => 'Failed to insert record.']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing required data.']);
}

$conn->close();
?>
