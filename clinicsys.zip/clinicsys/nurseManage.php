    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>SMC Clinic Dashboard - Manage</title>
    <style>
        body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        }
        .sidebar {
        width: 200px;
        height: 100vh;
        background-color: #f5f5f5;
        position: fixed;
        left: 0;
        top: 0;
        padding: 20px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }
        .sidebar h2 {
        font-size: 18px;
        color: #333;
        margin-bottom: 20px;
        }
        .sidebar a {
        display: block;
        text-decoration: none;
        color: #333;
        padding: 10px;
        margin-bottom: 5px;
        border-radius: 5px;
        }
        .sidebar a:hover,
        .sidebar a.active {
        background-color: #2c7df7;
        color: white;
        }
        .header {
        background-color: #2c7df7;
        color: white;
        padding: 15px;
        font-size: 20px;
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        z-index: 1;
        }
        .logout-link {
        color: white;
        text-decoration: none;
        position: absolute;
        right: 50px;
        top: 15px;
        font-size: 15px;
        background-color: #1f5edb;
        padding: 5px 10px;
        border-radius: 5px;
        transition: background 0.3s ease;
        }
        .main-content {
        margin-left: 220px;
        padding: 100px 20px 20px 20px;
        }
        .tabs {
        margin-top: 20px;
        margin-left: 15px;
        display: flex;
        border-bottom: 2px solid #2c7df7;
        }
        .tab {
        padding: 10px 20px;
        cursor: pointer;
        font-weight: bold;
        text-decoration: none;
        color: #333;
        }
        .tab:hover,
        .tab.active {
        background-color: #2c7df7;
        color: white;
        border-radius: 5px 5px 0 0;
        }
        .content {
        background: white;
        padding: 20px;
        border-radius: 5px;
        margin-top: -2px;
        margin-left: 15px;
        }
        .input-form input {
        width: 100%;
        padding: 8px;
        margin: 10px 0;
        border-radius: 5px;
        border: 1px solid #ccc;
        }
        .input-form button {
        padding: 10px 15px;
        background-color: #2c7df7;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        }
        .input-form button:hover {
        background-color: #1f5edb;
        }
    </style>
    </head>
    <body>
    <div class="sidebar">
    <h2>SMC Clinic</h2>
    <a href="nurseDashBoard.php">Appointments</a>
    <a href="nurseClinic.php">Clinic</a>
    <a href="nurseInventory.php" class="active">Inventory</a>
    <a href="patientList.php">Patient List</a>
    </div>

    <div class="header">
    SMC Clinic Dashboard
    <a href="logout.php" class="logout-link">Log Out</a>
    </div>

    <div class="main-content">
    <div class="tabs">
        <a href="#" class="tab active">Manage</a>
        <a href="nurseInventory.php" class="tab">Inventory</a>
    </div>
    <div class="content">
        <div class="input-form">
        <label for="student-name">Student Name</label>
        <input type="text" id="student-name" />
        <label for="student-id">Student ID</label>
        <input type="text" id="student-id" />
        <label for="medicine-name">Medicine Name</label>
        <input type="text" id="medicine-name" />
        <label for="medicine-qty">Quantity</label>
        <input type="number" id="medicine-qty" min="1" />
        <label for="reason">Reason</label>
        <input type="text" id="reason" />
        <button onclick="submitRecord()">Submit</button>
        </div>
    </div>
    </div>

    <script>
    function getRecords() {
        return JSON.parse(localStorage.getItem("manageRecords")) || [];
    }

    function saveRecords(data) {
        localStorage.setItem("manageRecords", JSON.stringify(data));
    }

    function getInventory() {
        return JSON.parse(localStorage.getItem("inventory")) || [];
    }

    function saveInventory(data) {
        localStorage.setItem("inventory", JSON.stringify(data));
    }

    function submitRecord() {
        const student = document.getElementById("student-name").value.trim();
        const studentId = document.getElementById("student-id").value.trim().toUpperCase();
        const medicine = document.getElementById("medicine-name").value.trim();
        const quantity = parseInt(document.getElementById("medicine-qty").value);
        const reason = document.getElementById("reason").value.trim();

        const studentData = {
        "Christian James Usman": "C23-0232",
        "Janah Baltazar": "C23-0007"
        };

        if (!student || !studentId || !medicine || isNaN(quantity) || quantity <= 0 || !reason) {
        alert("Please fill out all fields correctly.");
        return;
        }

        if (!studentData[student] || studentData[student] !== studentId) {
        alert("Student name and ID do not match.");
        return;
        }

        let records = getRecords();
        records.unshift({
        student,
        studentId,
        medicine,
        quantity,
        reason,
        status: quantity > 0 ? "Available" : "Not Available"
        });

        let inventory = getInventory();
        let existingMedicine = inventory.find(med => med.name.toLowerCase() === medicine.toLowerCase());

        if (existingMedicine) {
        if (existingMedicine.remaining >= quantity) {
            existingMedicine.remaining -= quantity;
            existingMedicine.status = existingMedicine.remaining > 0 ? "Available" : "Not Available";
        } else {
            alert("Not enough stock available.");
            return;
        }
        } else {
        alert("Medicine not found in inventory.");
        return;
        }

        saveInventory(inventory);
        saveRecords(records);

        document.getElementById("student-name").value = "";
        document.getElementById("student-id").value = "";
        document.getElementById("medicine-name").value = "";
        document.getElementById("medicine-qty").value = "";
        document.getElementById("reason").value = "";
    }
    </script>
    </body>
    </html>
