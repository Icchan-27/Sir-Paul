<?php
include 'connect.php';

$query = "SELECT * FROM inventory";
$result = $conn->query($query);


while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['inventory_id'] . "</td>";
    echo "<td>" . $row['medicine_name'] . "</td>";
    echo "<td>" . $row['stockremaining'] . "</td>";
    echo "<td>" . $row['totalstock'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "</tr>";
}

?>
