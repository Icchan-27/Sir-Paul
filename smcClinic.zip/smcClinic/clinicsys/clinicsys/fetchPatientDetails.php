    <?php
    include 'connect.php';

    if (!isset($_GET['id'])) {
    echo 'No ID provided.';
    exit;
    }

    $id = $_GET['id'];

    $apptQuery = "SELECT * FROM appointments WHERE patient_id = ?";
    $stmt = $conn->prepare($apptQuery);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $apptResult = $stmt->get_result();

    echo "<h4>Appointments</h4>";
    if ($apptResult->num_rows > 0) {
    while ($row = $apptResult->fetch_assoc()) {
        echo "<div>Date: {$row['appointmentDate']} | Time: {$row['appointmentTime']} | Status: {$row['Status']}</div>";
    }
    } else {
    echo "<div>No appointments found.</div>";
    }

    $txnQuery = "SELECT * FROM records WHERE patient_id = ?";
    $stmt = $conn->prepare($txnQuery);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $txnResult = $stmt->get_result();

    echo "<h4>Records</h4>";
    if ($txnResult->num_rows > 0) {
    while ($row = $txnResult->fetch_assoc()) {
        echo "<div>Medicine: {$row['medicine_name']} | Qty: {$row['quantity']} | Reason: {$row['reason']}</div>";
    }
    } else {
    echo "<div>No Records found.</div>";
    }
    ?>