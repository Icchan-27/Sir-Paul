<div class="content-wrapper">
    <h2><i class="fas fa-headset" style="color: #a0522d;"></i> Customer Service</h2>
    <p>
        We're here to assist you with any inquiries or concerns you may have. Please feel free to reach out to us through the following channels:
    </p>
    <div style="margin-top: 20px;">
        <strong>Contact Numbers:</strong><br>
        +63 918 913 0817<br>
        +63 995 650 6920
    </div>
    <div style="margin-top: 15px;">
        <strong>Email:</strong><br>
        <a href="mailto:customer.service@sebomassageandspa.com">customer.service@sebomassageandspa.com</a>
    </div>
    <p style="margin-top: 20px;">
        Our dedicated customer service team is ready to provide you with the support you need.
    </p>
</div>