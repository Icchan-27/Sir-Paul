<?php
session_start();
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    function verify_password($input_password, $db_password) {
        if (password_get_info($db_password)['algo']) {
            return password_verify($input_password, $db_password);
        } else {
            return $input_password === $db_password;
        }
    }

        // Check in admins table (for both admin and staff accounts)
    $query_admin = "SELECT * FROM admins WHERE name = '$username' LIMIT 1";
    $result_admin = $conn->query($query_admin);

    if ($result_admin && $result_admin->num_rows === 1) {
        $admin = $result_admin->fetch_assoc();

        if (verify_password($password, $admin['password'])) {
            $_SESSION['user_role'] = strtolower($admin['name']); // will be 'admin' or 'staff'
            $_SESSION['user_name'] = $admin['name'];
            $_SESSION['user_id'] = $admin['admin_id'];

            echo "<script>
                    alert('Welcome, " . ucfirst($admin['name']) . "!');
                    window.location.href = 'admin_dashboard.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Incorrect password.');
                    window.location.href = 'sebo_login.php';
                  </script>";
        }
        exit();
    }

    $query_customer = "SELECT * FROM customer WHERE username = '$username' LIMIT 1";
    $result_customer = $conn->query($query_customer);

    if ($result_customer && $result_customer->num_rows === 1) {
        $customer = $result_customer->fetch_assoc();

        if (verify_password($password, $customer['password'])) {
            $_SESSION['user_role'] = 'customer';
            $_SESSION['user_name'] = $customer['username'];
            $_SESSION['user_id'] = $customer['customer_id'];

            echo "<script>
                    alert('Welcome, Customer!');
                    window.location.href = 'customer_dashboard.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Incorrect password for customer.');
                    window.location.href = 'sebo_login.php';
                  </script>";
        }
        exit();
    }

    echo "<script>
            alert('Username not found.');
            window.location.href = 'sebo_login.php';
          </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Sebo Massage Login</title>
    <style>
        * {
            margin: 0; padding: 0; box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        .left-side {
            flex: 1;
            background-color: rgb(58, 34, 14);
            padding: 40px 60px;
            color: rgb(247, 245, 243);
            display: flex;
            flex-direction: column;
            justify-content: center;
            gap: 40px;
            font-size: 16px;
            line-height: 1.5;
            overflow-y: auto;
        }
        .welcome-text h2 {
            font-size: 28px;
            color: rgb(232, 182, 158);
            margin-bottom: 15px;
            font-weight: 600;
            text-align: center;
        }
        .welcome-text p {
            margin-bottom: 10px;
            text-align: center;
        }
        .about-text {
            margin-top: 40px;
        }
        .about-text h3 {
            font-size: 22px;
            color: #a0522d;
            margin-bottom: 15px;
            font-weight: 600;
            text-align: center;
        }
        .about-text p {
            margin-bottom: 10px;
            font-size: 14px;
            text-align: justify;
        }
        .right-side {
            width: 30%;
            background-color: rgb(100, 64, 36);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            text-align: center;
        }
        .logo {
            width: 230px;
            margin-bottom: 20px;
        }
        .input-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 80%;
            max-width: 350px;
            text-align: left;
        }
        .input-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .input-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .input-container input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .buttons {
            display: flex;
            justify-content: space-between;
        }
        .buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
        }
        .login {
            background-color: rgb(66, 47, 20);
            color: white;
        }
        .signup {
            background-color: white;
            border: 1px solid rgb(64, 43, 6);
            color: rgb(75, 54, 27);
        }
        .signup:hover {
            background-color: rgb(54, 33, 14);
            color: white;
        }
    </style>
</head>
<body>

    <div class="left-side">
        <div class="welcome-text">
            <h2>Welcome to Sebo Massage</h2>
            <p>Experience the perfect blend of relaxation and healing with our premium massage services.</p>
            <p>Please select an option from the navigation bar to begin your journey to wellness.</p>
        </div>
        <div class="about-text">
            <h3>About Sebo Massage</h3>
            <p>Welcome to Sebo Massage, where we are dedicated to providing an unparalleled experience in relaxation and rejuvenation. Our team of skilled therapists is committed to your well-being, ensuring that every visit leaves you feeling refreshed and revitalized.</p>
            <p>Sebo Massage is one of the fast-growing franchise networks in the Philippines. Our commitment to quality and customer satisfaction has made us a trusted name in the wellness industry.</p>
            <p>We offer a variety of massage therapies tailored to meet your individual needs. Whether you seek relief from muscle tension, stress reduction, or a moment of tranquility, Sebo Massage is your haven.</p>
        </div>
    </div>

    <div class="right-side">
        <img src="sebo-logo.png" alt="Sebo Massage Logo" class="logo" />
        <form class="input-container" method="POST" action="">
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter username" required />

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter password" required />

            <div class="buttons">
                <button type="button" class="signup" onclick="redirectToSignUp()">Sign Up</button>
                <button type="submit" class="login">Login</button>
            </div>
        </form>
    </div>

    <script>
function redirectToSignUp() {
    window.location.href = "<?php echo '/xampp.sebo/sebocustomer_sign_up.php'; ?>";
}
</script>

</body>
</html>