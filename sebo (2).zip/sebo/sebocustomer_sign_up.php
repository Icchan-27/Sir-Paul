<?php
session_start();
require_once 'connection.php'; // your DB connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        isset($_POST['massage_type']) &&
        isset($_POST['date']) &&
        isset($_POST['time_slot']) &&
        isset($_POST['duration']) &&
        isset($_POST['totalAmount'])
    ) {
        $service_name = $conn->real_escape_string($_POST['massage_type']);
        $booking_date = $conn->real_escape_string($_POST['date']);
        $timeSlot = $conn->real_escape_string($_POST['time_slot']);
        $duration = $conn->real_escape_string($_POST['duration']);
        $totalAmount = (float) $_POST['totalAmount'];

        $sql = "INSERT INTO service (service_name, booking_date, timeSlot, duration, totalAmount) 
                VALUES (?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("ssssd", $service_name, $booking_date, $timeSlot, $duration, $totalAmount);

        if ($stmt->execute()) {
            echo "<script>alert('Booking successful!'); window.location.href='dashboard.php';</script>";
            exit;
        } else {
            $error = "Booking failed: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error = "Please fill all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Book a Massage Service</title>
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #6B4226;
    color: #FFF8F0;
    margin: 0;
    padding: 40px 20px;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
  }
  form {
    background: transparent;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(75, 46, 21, 0.4);
    padding: 30px 35px;
    width: 100%;
    max-width: 480px;
  }
  h2 {
    margin-top: 0;
    text-align: center;
    font-weight: 700;
    font-size: 1.5rem;
    letter-spacing: 1.1px;
    margin-bottom: 25px;
    color: #4B2E15;
  }
  label {
    display: block;
    margin: 15px 0 6px;
    font-weight: 600;
    font-size: 1rem;
    color: #4B2E15;
  }
  select,
  input[type="date"] {
    width: 100%;
    padding: 12px 14px;
    font-size: 1rem;
    border: none;
    border-radius: 8px;
    background: #f2e3d0;
    color: #3F2A1D;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
    transition: box-shadow 0.3s ease;
  }
  select:focus,
  input[type="date"]:focus {
    outline: none;
    box-shadow: 0 0 8px #D1B07F;
  }
  option {
    font-weight: 600;
  }
  #service-details {
    margin-top: 25px;
    background: #8C6E63;
    border-radius: 10px;
    padding: 15px 20px;
    color: #FFF8F0;
    font-size: 1.2rem;
    font-weight: 700;
    box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.15);
    display: block;
    text-align: center;
  }
  button {
    margin-top: 30px;
    width: 100%;
    background-color: #4B2E15;
    color: #FFF8F0;
    font-weight: 700;
    font-size: 1.1rem;
    padding: 14px 0;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(75, 46, 21, 0.5);
    transition: background-color 0.3s ease, box-shadow 0.3s ease;
  }
  button:hover {
    background-color: #6B4226;
    box-shadow: 0 6px 14px rgba(107, 66, 38, 0.7);
  }
  .error-message {
    margin-top: 15px;
    color: #ff6666;
    font-weight: 700;
    text-align: center;
  }
</style>
</head>
<body>

<form id="booking-form" method="POST" action="" autocomplete="off">
  <h2>Book a Massage Service</h2>

  <?php if (!empty($error)): ?>
    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
  <?php endif; ?>

  <label for="massage_type">Select Massage Type:</label>
  <select name="massage_type" id="massage_type" required>
    <option value="" disabled selected>-- Select Massage Type --</option>
    <option value="Swedish Massage">Swedish Massage</option>
    <option value="Deep Tissue Massage">Deep Tissue Massage</option>
    <option value="Aromatherapy Massage">Aromatherapy Massage</option>
    <option value="Hot Stone Massage">Hot Stone Massage</option>
    <option value="Thai Massage">Thai Massage</option>
  </select>

  <label for="date">Select Date:</label>
  <input type="date" id="date" name="date" required min="<?php echo date('Y-m-d'); ?>">

  <label for="time_slot">Select Time Slot:</label>
  <select name="time_slot" id="time_slot" required>
    <option value="" disabled selected>-- Select Time Slot --</option>
    <option value="morning">Morning (7 AM - 9 AM)</option>
    <option value="midday">Midday (9 AM - 12 NN)</option>
    <option value="afternoon">Afternoon (12 NN - 3 PM)</option>
  </select>

  <label for="duration">Select Duration:</label>
  <select name="duration" id="duration" required>
    <option value="" disabled selected>-- Select Duration --</option>
    <option value="1">1 HOUR WHOLE BODY MASSAGE</option>
    <option value="1.5">1.5 HOUR WHOLE BODY MASSAGE</option>
    <option value="2">2 HOUR WHOLE BODY MASSAGE</option>
  </select>

  <div id="service-details">
    Price: ₱<span id="price">0</span>
  </div>

  <input type="hidden" name="totalAmount" id="hidden_totalAmount" value="">

  <button type="submit">Book Now</button>
</form>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const priceSpan = document.getElementById('price');
  const hiddenTotalAmount = document.getElementById('hidden_totalAmount');

  function updatePrice() {
    const timeSlot = document.getElementById('time_slot').value;
    const duration = document.getElementById('duration').value;

    let price = 0;

    if (timeSlot && duration) {
      if (timeSlot === "morning") {
        price = duration === "1" ? 150 :
                duration === "1.5" ? 225 :
                duration === "2" ? 300 : 0;
      } else if (timeSlot === "midday") {
        price = duration === "1" ? 250 :
                duration === "1.5" ? 375 :
                duration === "2" ? 500 : 0;
      } else if (timeSlot === "afternoon") {
        price = duration === "1" ? 300 :
                duration === "1.5" ? 450 :
                duration === "2" ? 600 : 0;
      }
    }

    priceSpan.textContent = price;
    hiddenTotalAmount.value = price;
  }

  document.getElementById('time_slot').addEventListener('change', updatePrice);
  document.getElementById('duration').addEventListener('change', updatePrice);
});
</script>

</body>
</html>
