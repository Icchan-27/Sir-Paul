<?php
session_start(); 

include 'connection.php';

function handleSignup($conn) {
    if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['age']) && isset($_POST['gender']) && isset($_POST['contact'])) {

        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $contact = $_POST['contact'];

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(array("status" => "error", "message" => "Invalid email format"));
            return;
        }
        if ($age < 10 || $age > 65) {
            echo json_encode(array("status" => "error", "message" => "Age must be between 10 and 65."));
            return;
        }
        if (strlen($contact) !== 11 || !ctype_digit($contact)) {
            echo json_encode(array("status" => "error", "message" => "Contact number must be 11 digits and contain only numbers."));
            return;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if ($row['username'] === $username) {
                echo json_encode(array("status" => "error", "message" => "Username already exists"));
            } else {
                echo json_encode(array("status" => "error", "message" => "Email already exists"));
            }
            $stmt->close();
            return;
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO users (username, email, password, age, gender, contact) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $email, $hashedPassword, $age, $gender, $contact);

        if ($stmt->execute()) {
            echo json_encode(array("status" => "success", "message" => "Signup successful"));
            $_SESSION['username'] = $username;
        } else {
            echo json_encode(array("status" => "error", "message" => "Error: " . $stmt->error));
        }

        $stmt->close();
    } else {
        echo json_encode(array("status" => "error", "message" => "Missing required fields"));
    }
}

if (isset($_POST['action']) && $_POST['action'] == 'signup') {
    handleSignup($conn);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid action."));
}

$conn->close();
?>