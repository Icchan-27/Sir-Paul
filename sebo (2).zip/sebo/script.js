// Toggle sidebar open/close
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const hamburger = document.querySelector('.hamburger');
    sidebar.classList.toggle('active');

    if (sidebar.classList.contains('active')) {
        hamburger.innerHTML = '<i class="fas fa-times"></i>'; // X icon
    } else {
        hamburger.innerHTML = '<i class="fas fa-bars"></i>'; // Hamburger icon
    }
}

// Set inner HTML of main content area
function setContent(html) {
    document.getElementById("main-content").innerHTML = html;
}

// Load a page's HTML into main content, and close sidebar if open
function loadContent(page) {
    fetch(page)
        .then(response => response.text())
        .then(data => {
            setContent(data);
            const sidebar = document.getElementById('sidebar');
            if (sidebar.classList.contains('active')) {
                toggleSidebar();
            }
        })
        .catch(error => {
            console.error('Error loading content:', error);
            setContent('<p class="error-message">Failed to load content.</p>');
        });
}

// Show home page content
function showHome() {
    loadContent('home.php');
}

// Logout handler
function showLogout() {
    window.location.href = 'logout.php';
}

// Attach AJAX form handler for register form after loading form HTML
function attachRegisterFormHandler() {
    const form = document.getElementById('registerForm');
    const messageDiv = document.getElementById('registerMessage');

    if (!form) return;

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(form);

        fetch('register.php', {
            method: 'POST',
            body: formData,
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                messageDiv.innerHTML = '<p style="color:green;">Registration successful! You can now log in.</p>';
                form.reset();
            } else if (data.status === 'error') {
                messageDiv.innerHTML = `<p style="color:red;">${data.message}</p>`;
            }
        })
        .catch(err => {
            messageDiv.innerHTML = '<p style="color:red;">An error occurred. Please try again.</p>';
            console.error('Register error:', err);
        });
    });
}

// Load the register form HTML dynamically and attach form submit handler
function loadSignupForm() {
    fetch('register_form.php')
        .then(response => response.text())
        .then(html => {
            setContent(html);
            attachRegisterFormHandler();
        })
        .catch(err => {
            console.error('Error loading sign-up form:', err);
            setContent('<p class="error-message">Failed to load sign-up form.</p>');
        });
}

// Attach any other event listeners when DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {
    // Optionally attach sidebar toggle or other handlers here if needed
});
