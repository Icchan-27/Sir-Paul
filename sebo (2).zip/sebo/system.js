let adminLoggedIn = false;
let userLoggedIn = false;
let currentLoggedInUser = null;
const formData = { users: [] };
let archiveData = [];

const timeSlots = {
    morning: { name: "7 AM to 9 AM", prices: { "1hour": 150, "1.5hour": 225, "2hour": 300 } },
    midday: { name: "9 AM to 12 NN", prices: { "1hour": 250, "1.5hour": 375, "2hour": 500 } },
    afternoon: { name: "12 NN to 3 PM", prices: { "1hour": 300, "1.5hour": 450, "2hour": 600 } }
};

const durations = {
    "1hour": "1 HOUR WHOLE BODY MASSAGE",
    "1.5hour": "1.5 HOUR WHOLE BODY MASSAGE",
    "2hour": "2 HOUR WHOLE BODY MASSAGE"
};

const massageTypes = {
    swedish: { name: "Swedish Massage", benefits: "Swedish massage uses long, flowing strokes to promote relaxation, ease muscle tension, and improve circulation. Benefits include stress reduction, increased flexibility, relief from muscle tension, improved blood circulation, and enhanced mood through the release of endorphins." },
    thai: { name: "Thai Massage", benefits: "Thai massage combines acupressure, Indian Ayurvedic principles, and assisted yoga postures. Benefits include improved flexibility, relief of muscle tension, enhanced energy flow, better circulation, and increased range of motion. It's often called 'lazy person's yoga' as the therapist moves your body into various poses." },
    shiatsu: { name: "Shiatsu Massage", benefits: "Shiatsu is a Japanese therapy that uses finger pressure on specific points along the body's meridians. Benefits include reduced stress and tension, relieved headaches, improved circulation, stimulated immune system, and restored energy balance throughout the body." },
    combination: { name: "Combination Massage", benefits: "Our combination massage integrates techniques from Swedish, Thai, and Shiatsu for a complete therapeutic experience. Benefits include comprehensive stress relief, balanced energy flow, deep muscle relaxation, improved circulation, enhanced mood, and a customized approach that addresses your specific needs." }
};

const addons = {
    hotStone: { name: "Hot Stone Therapy", description: "Enhance your massage with heated stones that deeply penetrate muscles to release tension and promote relaxation.", price: 50, duration: "20 mins" }
};

const toggleSidebar = () => {
    const sidebar = document.getElementById('sidebar');
    const hamburger = document.querySelector('.hamburger');
    sidebar.classList.toggle('active');
    hamburger.classList.toggle('hidden');
};

const setContent = html => {
    const mainContent = document.getElementById("main-content");
    mainContent.innerHTML = html;
    mainContent.classList.remove('content-wrapper');
    mainContent.classList.add('content-wrapper');
};

const showHome = () => setContent(`<h1><i class="fas fa-spa"></i> Welcome to Sebo Massage</h1><p>Experience the perfect blend of relaxation and healing with our premium massage services.</p><p>Please select an option from the sidebar to begin your journey to wellness.</p><div style="margin-top: 30px;"><i class="fas fa-hands" style="font-size: 50px; color: #d4af7a; margin: 0 15px;"></i><i class="fas fa-hot-tub" style="font-size: 50px; color: #d4af7a; margin: 0 15px;"></i><i class="fas fa-spa" style="font-size: 50px; color: #d4af7a; margin: 0 15px;"></i></div>`);

const showLogin = () => setContent(`<h2><i class="fas fa-sign-in-alt"></i> Log In</h2><input type="text" id="login-username" placeholder="Username" /><input type="password" id="login-password" placeholder="Password" /><div id="login-error" class="error-message" style="display:none;"></div><div class="form-buttons"><button onclick="login()"><i class="fas fa-unlock"></i> Log In</button><button onclick="showHome()"><i class="fas fa-times"></i> Cancel</button></div><p style="margin-top: 20px; font-size: 14px;">Don't have an account? <span style="color: #d4af7a; cursor: pointer; text-decoration: underline;" onclick="showSignUp()">Sign up here</span></p>`);

const login = () => {
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;
    const loginError = document.getElementById("login-error");
    loginError.style.display = "none";
    if (username === "admin" && password === "admin123") {
        adminLoggedIn = true;
        updateSidebarForAdmin();
        showAdminDashboard();
        return;
    }
    const user = formData.users.find(u => u.username === username && u.password === password);
    if (user) {
        userLoggedIn = true;
        currentLoggedInUser = user;
        updateSidebarForLoggedInUser();
        showUserDashboard();
    } else {
        loginError.textContent = "Invalid username or password.";
        loginError.style.display = "block";
    }
};

const showSignUp = () => setContent(`<h2><i class="fas fa-user-plus"></i> Sign Up</h2><input type="text" id="signup-username" placeholder="Username" /><input type="email" id="signup-email" placeholder="Email (@gmail.com required)" /><input type="number" id="signup-age" placeholder="Age" /><input type="text" id="signup-gender" placeholder="Gender" /><input type="text" id="signup-contact" placeholder="Contact No. (11 digits)" maxlength="11" /><input type="password" id="signup-password" placeholder="Password" /><div id="validation-message" class="error-message" style="display:none;"></div><div class="form-buttons"><button onclick="submitSignUp()"><i class="fas fa-paper-plane"></i> Submit</button><button onclick="showHome()"><i class="fas fa-times"></i> Cancel</button></div><p style="margin-top: 20px; font-size: 14px;">Already have an account? <span style="color: #d4af7a; cursor: pointer; text-decoration: underline;" onclick="showLogin()">Log in here</span></p>`);

const submitSignUp = () => {
    const username = document.getElementById("signup-username").value.trim();
    const email = document.getElementById("signup-email").value.trim();
    const age = document.getElementById("signup-age").value.trim();
    const gender = document.getElementById("signup-gender").value.trim();
    const contact = document.getElementById("signup-contact").value.trim();
    const password = document.getElementById("signup-password").value.trim();
    const validationMessage = document.getElementById("validation-message");
    validationMessage.style.display = "none";
    if (!username || !email || !age || !gender || !contact || !password) {
        validationMessage.textContent = "⚠ You need to fill out all fields before proceeding.";
        validationMessage.style.display = "block";
        return;
    }
    if (formData.users.some(u => u.username === username)) {
        validationMessage.textContent = "⚠ Username already exists. Please choose another.";
        validationMessage.style.display = "block";
        return;
    }
    if (!email.toLowerCase().endsWith("@gmail.com")) {
        validationMessage.textContent = "⚠ Email must end with @gmail.com";
        validationMessage.style.display = "block";
        return;
    }
    if (contact.length !== 11 || !/^\d{11}$/.test(contact)) {
        validationMessage.textContent = "⚠ Contact number must be exactly 11 digits";
        validationMessage.style.display = "block";
        return;
    }
    formData.users.push({ username, email, age, gender, contact, password, selectedMassage: null, selectedTimeSlot: null, selectedDuration: null, addons: {} });
    alert("Account created successfully! You can now log in.");
    showLogin();
};

function showUserDashboard() {
    updateSidebarForLoggedInUser();
    let dashboardContent = `<div class="welcome-user"><i class="fas fa-user-circle"></i> Welcome, ${currentLoggedInUser.username}!</div>`;

    if (currentLoggedInUser.selectedMassage) {
        dashboardContent += `
            <h3><i class="fas fa-spa"></i> Your Selected Massage</h3>
            <div class="massage-option selected-massage">
                <h3><span class="math-inline">\{massageTypes\[currentLoggedInUser\.selectedMassage\]\.name\}</h3\>
<div class\="massage\-description"\></span>{massageTypes[currentLoggedInUser.selectedMassage].benefits}</div>
            </div>
        `;

        if (currentLoggedInUser.selectedTimeSlot && currentLoggedInUser.selectedDuration) {
            const price = timeSlots[currentLoggedInUser.selectedTimeSlot].prices[currentLoggedInUser.selectedDuration];
            dashboardContent += `
                <h3><i class="fas fa-calendar-alt"></i> Your Appointment Details</h3>
                <div class="time-slot-option selected">
                    <h4><i class="fas fa-clock"></i> Time Slot: ${timeSlots[currentLoggedInUser.selectedTimeSlot].name}</h4>
                    <h4><i class="fas fa-hourglass-half"></i> Duration: <span class="math-inline">\{durations\[currentLoggedInUser\.selectedDuration\]\}</h4\>
<p class\="price\-highlight"\><i class\="fas fa\-tag"\></i\> Price\: ₱</span>{price}</p>
                </div>
                <div class="form-buttons">
                    <button onclick="showTimeSlotSelection()"><i class="fas fa-edit"></i> Change Time/Duration</button>
                </div>
            `;
        } else {
            dashboardContent += `
                <h3><i class="fas fa-calendar-plus"></i> Select Appointment Time and Duration</h3>
                <p>Choose when you'd like to schedule your massage therapy session.</p>
                <div class="form-buttons">
                    <button onclick="showTimeSlotSelection()"><i class="fas fa-clock"></i> Select Time & Duration</button>
                </div>
            `;
        }

        const hasHotStone = currentLoggedInUser.addons && currentLoggedInUser.addons.hotStone;
        dashboardContent += `
            <h3><i class="fas fa-plus-circle"></i> Enhance Your Experience</h3>
            <div class="addon-option ${hasHotStone ? 'selected' : ''}" onclick="toggleAddon('hotStone')">
                <input type="checkbox" class="addon-checkbox" <span class="math-inline">\{hasHotStone ? 'checked' \: ''\} onclick\="event\.stopPropagation\(\);"\>
<div class\="addon\-info"\>
<h4\></span>{addons.hotStone.name}</h4>
                    <p>${addons.hotStone.description}</p>
                    <p><em><i class="fas fa-hourglass-half"></i> Duration: <span class="math-inline">\{addons\.hotStone\.duration\}</em\></p\>
</div\>
<div class\="addon\-price"\>₱</span>{addons.hotStone.price}</div>
            </div>
            <div class="form-buttons">
                <button onclick="showMassageSelection()"><i class="fas fa-exchange-alt"></i> Change Massage Type</button>
            </div>
        `;
    } else {
        dashboardContent += `
            <h3><i class="fas fa-hand-holding-heart"></i> Begin Your Wellness Journey</h3>
            <p>Choose from our selection of therapeutic massages to experience deep relaxation and healing.</p>
            <div class="form-buttons">
                <button onclick="showMassageSelection()"><i class="fas fa-list-ul"></i> Browse Massage Types</button>
            </div>
        `;
    }

    dashboardContent += `<button class="logout-btn" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Log Out</button>`;
    setContent(dashboardContent);
}

function showTimeSlotSelection() {
    let timeSlotOptionsHtml = '<h3><i class="fas fa-clock"></i> Select Time Slot</h3>';
    for (const [key, timeSlot] of Object.entries(timeSlots)) {
        const isSelected = currentLoggedInUser.selectedTimeSlot === key;
        timeSlotOptionsHtml += `
            <div class="time-slot-option <span class="math-inline">\{isSelected ? 'selected' \: ''\}" onclick\="selectTimeSlot\('</span>{key}')">
                <h4><i class="fas fa-clock"></i> <span class="math-inline">\{timeSlot\.name\}</h4\>
<p\><i class\="fas fa\-tag"\></i\> 1 Hour\: <span class\="price\-highlight"\>₱</span>{timeSlot.prices["1hour"]}</span></p>
                <p><i class="fas fa-tag"></i> 1.5 Hours: <span class="price-highlight">₱<span class="math-inline">\{timeSlot\.prices\["1\.5hour"\]\}</span\></p\>
<p\><i class\="fas fa\-tag"\></i\> 2 Hours\: <span class\="price\-highlight"\>₱</span>{timeSlot.prices["2hour"]}</span></p>
            </div>
        `;
    }

    timeSlotOptionsHtml += '<h3 style="margin-top: 40px;"><i class="fas fa-hourglass-half"></i> Select Duration</h3>';
    for (const [key, value] of Object.entries(durations)) {
        const isSelected = currentLoggedInUser.selectedDuration === key;
        timeSlotOptionsHtml += `
            <div class="duration-option <span class="math-inline">\{isSelected ? 'selected' \: ''\}" onclick\="selectDuration\('</span>{key}')">
                <h4>${value}</h4>
            </div>
        `;
    }

    timeSlotOptionsHtml += `<div class="form-buttons"><button onclick="saveTiming()"><i class="fas fa-save"></i> Save Selection</button><button onclick="showUserDashboard()"><i class="fas fa-times"></i> Cancel</button></div>`;
    setContent(timeSlotOptionsHtml);
}

const selectTimeSlot = slot => {
    document.querySelector('.time-slot-option.selected')?.classList.remove('selected');
    const selectedSlotElement = Array.from(document.querySelectorAll('.time-slot-option')).find(el => el.querySelector('h4').textContent.includes(timeSlots[slot].name));
    if (selectedSlotElement) {
        selectedSlotElement.classList.add('selected');
        formData.users = formData.users.map(user =>
            user.username === currentLoggedInUser.username ? { ...user, selectedTimeSlot: slot } : user
        );
        currentLoggedInUser.selectedTimeSlot = slot;
    }
};

const selectDuration = duration => {
    document.querySelector('.duration-option.selected')?.classList.remove('selected');
    const selectedDurationElement = Array.from(document.querySelectorAll('.duration-option')).find(el => el.querySelector('h4').textContent === durations[duration]);
    if (selectedDurationElement) {
        selectedDurationElement.classList.add('selected');
        formData.users = formData.users.map(user =>
            user.username === currentLoggedInUser.username ? { ...user, selectedDuration: duration } : user
        );
        currentLoggedInUser.selectedDuration = duration;
    }
};

const saveTiming = () => {
    currentLoggedInUser.selectedTimeSlot && currentLoggedInUser.selectedDuration ? showUserDashboard() : alert("Please select both a time slot and a duration.");
};

function showMassageSelection() {
    let massageOptionsHtml = '<h2><i class="fas fa-list-ul"></i> Choose Your Massage</h2>';
    for (const [key, massage] of Object.entries(massageTypes)) {
        const isSelected = currentLoggedInUser.selectedMassage === key;
        massageOptionsHtml += `
            <div class="massage-option <span class="math-inline">\{isSelected ? 'selected' \: ''\}" onclick\="selectMassage\('</span>{key}')">
                <h3><span class="math-inline">\{massage\.name\}</h3\>
<div class\="massage\-description"\></span>{massage.benefits}</div>
            </div>
        `;
    }
    massageOptionsHtml += `<div class="form-buttons"><button onclick="showUserDashboard()"><i class="fas fa-arrow-left"></i> Back to Dashboard</button></div>`;
    setContent(massageOptionsHtml);
}

const selectMassage = type => {
    formData.users = formData.users.map(user =>
        user.username === currentLoggedInUser.username ? { ...user, selectedMassage: type } : user
    );
    currentLoggedInUser.selectedMassage = type;
    showUserDashboard();
};

const toggleAddon = addonKey => {
    const addonElement = Array.from(document.querySelectorAll('.addon-option')).find(el => el.querySelector('h4').textContent === addons[addonKey].name);
    if (addonElement) {
        addonElement.classList.toggle('selected');
        formData.users = formData.users.map(user => {
            if (user.username === currentLoggedInUser.username) {
                const updatedAddons = { ...user.addons };
                updatedAddons[addonKey] ? delete updatedAddons[addonKey] : updatedAddons[addonKey] = true;
                return { ...user, addons: updatedAddons };
            }
            return user;
        });
        currentLoggedInUser.addons = currentLoggedInUser.addons || {};
        currentLoggedInUser.addons[addonKey] ? delete currentLoggedInUser.addons[addonKey] : currentLoggedInUser.addons[addonKey] = true;
    }
};

const showCustomerService = () => setContent(`<h2><i class="fas fa-headset"></i> Customer Service</h2> <p>Our dedicated customer service team is here to assist you with any inquiries or concerns.</p> <p><strong>Phone:</strong> (082) 123-4567</p> <p><strong>Email:</strong> support@sebomassage.com</p> <p><strong>Operating Hours:</strong> Monday - Sunday, 9:00 AM - 6:00 PM</p> <p>Feel free to reach out to us. We're happy to help!</p> <div style="margin-top: 30px;"> <i class="fas fa-phone-alt" style="font-size: 40px; color: #d4af7a; margin: 0 15px;"></i> <i class="fas fa-envelope" style="font-size: 40px; color: #d4af7a; margin: 0 15px;"></i> </div>`);

const showAboutUs = () => setContent(`<h2><i class="fas fa-info-circle"></i> About Us</h2> <p>Sebo Massage is dedicated to providing you with a tranquil and rejuvenating experience. Our skilled therapists are trained in a variety of massage techniques to cater to your individual needs.</p> <p>Our mission is to promote wellness and relaxation in a comfortable and serene environment. We believe in the power of touch to heal and restore balance to the body and mind.</p> <p>We use high-quality products and maintain the highest standards of hygiene to ensure your safety and comfort.</p> <p>Thank you for choosing Sebo Massage. We look forward to serving you!</p> <div style="margin-top: 30px;"> <i class="fas fa-leaf" style="font-size: 40px; color: #d4af7a; margin: 0 15px;"></i> <i class="fas fa-heartbeat" style="font-size: 40px; color: #d4af7a; margin: 0 15px;"></i> </div>`);

function showAdminDashboard() {
    updateSidebarForAdmin();
    const userList = formData.users.length > 0
        ? formData.users.map((user, index) => `
            <div class="user-card" onclick="showUserDetails(${index})">
                <strong>Username:</strong> ${user.username}<br>
                <strong>Email:</strong> ${user.email}<br>
                <em>Click for more details</em>
            </div>
        `).join('')
        : '<p>No users registered yet.</p>';

    const archiveButton = archiveData.length > 0
        ? `<button onclick="viewArchive()">View Archive (${archiveData.length})</button>`
        : '<p>No data has been archived.</p>';

    setContent(`
        <h2><i class="fas fa-user-shield"></i> Admin Dashboard</h2>
        <h3><i class="fas fa-users"></i> Registered Users</h3>
        ${userList}
        <h3><i class="fas fa-archive"></i> Archived Data</h3>
        ${archiveButton}
        <button class="logout-btn" onclick="logoutAdmin()"><i class="fas fa-sign-out-alt"></i> Log Out Admin</button>
    `);
}

function showUserDetails(index) {
    const user = formData.users[index];
    let userDetailsContent = `<h2><i class="fas fa-user-circle"></i> User Details</h2> <div class="user-details"> <p><strong>Username:</strong> ${user.username}</p> <p><strong>Email:</strong> ${user.email}</p> <p><strong>Age:</strong> ${user.age}</p> <p><strong>Gender:</strong> ${user.gender}</p> <p><strong>Contact No.:</strong> ${user.contact}</p>`;

    if (user.selectedMassage) {
        userDetailsContent += `
            <h3><i class="fas fa-spa"></i> Massage Preferences</h3>
            <p><strong>Type:</strong> ${massageTypes[user.selectedMassage].name}</p>
        `;
        if (user.selectedTimeSlot && user.selectedDuration) {
            const price = timeSlots[user.selectedTimeSlot].prices[user.selectedDuration];
            userDetailsContent += `
                <p><strong>Time Slot:</strong> ${timeSlots[user.selectedTimeSlot].name}</p>
                <p><strong>Duration:</strong> ${durations[user.selectedDuration]}</p>
                <p><strong>Price:</strong> ₱${price}</p>
            `;
        }
        if (user.addons && Object.keys(user.addons).length > 0) {
            userDetailsContent += `<p><strong>Add-ons:</strong> ${Object.keys(user.addons).map(key => addons[key].name).join(', ')}</p>`;
        }
    } else {
        userDetailsContent += `<p>No massage preferences selected yet.</p>`;
    }

    userDetailsContent += `
    </div>
    <div class="form-buttons">
        <button onclick="archiveUser(${index})"><i class="fas fa-archive"></i> Archive User</button>
        <button onclick="showAdminDashboard()"><i class="fas fa-arrow-left"></i> Back to Dashboard</button>
    </div>
`;
    setContent(userDetailsContent);
}

const archiveUser = index => {
    const userToArchive = formData.users.splice(index, 1)[0];
    archiveData.push(userToArchive);
    showAdminDashboard();
    alert(`User "${userToArchive.username}" has been archived.`);
};

function viewArchive() {
    const archiveViewContent = `
        <h2><i class="fas fa-box-archive"></i> Archived User Data</h2>
        ${archiveData.length > 0
            ? archiveData.map(user => `
                <div class="user-card">
                    <strong>Username:</strong> ${user.username}<br>
                    <strong>Email:</strong> ${user.email}<br>
                    <em>Archived on: ${new Date().toLocaleDateString()}</em>
                </div>
            `).join('')
            : '<p>No users in the archive.</p>'
        }
        <div class="form-buttons">
            <button onclick="showAdminDashboard()"><i class="fas fa-arrow-left"></i> Back to Admin Dashboard</button>
        </div>
    `;
    setContent(archiveViewContent);
}

const logout = () => {
    userLoggedIn = false;
    currentLoggedInUser = null;
    updateSidebarForLoggedOut();
    showHome();
    alert("Logged out successfully.");
};

const logoutAdmin = () => {
    adminLoggedIn = false;
    updateSidebarForLoggedOut();
    showHome();
    alert("Admin logged out.");
};

const updateSidebarForLoggedInUser = () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.innerHTML = `
        <button onclick="toggleSidebar(); showUserDashboard()"><i class="fas fa-tachometer-alt"></i> Dashboard</button>
        <button onclick="toggleSidebar(); showMassageSelection()"><i class="fas fa-spa"></i> Book Massage</button>
        <button onclick="toggleSidebar(); showCustomerService()"><i class="fas fa-headset"></i> Customer Service</button>
        <button onclick="toggleSidebar(); showAboutUs()"><i class="fas fa-info-circle"></i> About Us</button>
        <button onclick="logout()"><i class="fas fa-sign-out-alt"></i> Log Out</button>
    `;
};

const updateSidebarForAdmin = () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.innerHTML = `
        <button onclick="toggleSidebar(); showAdminDashboard()"><i class="fas fa-tachometer-alt"></i> Admin Dashboard</button>
        <button onclick="toggleSidebar(); showCustomerService()"><i class="fas fa-headset"></i> Customer Service</button>
        <button onclick="toggleSidebar(); showAboutUs()"><i class="fas fa-info-circle"></i> About Us</button>
        <button onclick="logoutAdmin()"><i class="fas fa-sign-out-alt"></i> Log Out Admin</button>
    `;
};

const updateSidebarForLoggedOut = () => {
    const sidebar = document.getElementById('sidebar');
    sidebar.innerHTML = `
        <button onclick="toggleSidebar(); showHome()"><i class="fas fa-home"></i> Home</button>
        <button onclick="toggleSidebar(); showLogin()"><i class="fas fa-sign-in-alt"></i> Log In</button>
        <button onclick="toggleSidebar(); showSignUp()"><i class="fas fa-user-plus"></i> Sign Up</button>
        <button onclick="toggleSidebar(); showCustomerService()"><i class="fas fa-headset"></i> Customer Service</button>
        <button onclick="toggleSidebar(); showAboutUs()"><i class="fas fa-info-circle"></i> About Us</button>
    `;
};

showHome();