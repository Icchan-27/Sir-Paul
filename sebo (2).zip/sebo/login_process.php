<?php
session_start();
include 'connection.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$log_file = 'login_debug.txt';
$log = function ($message) use ($log_file) {
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - " . $message . "\n", FILE_APPEND);
};

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim(mysqli_real_escape_string($conn, $_POST['login-name']));
    $password = trim($_POST['login-password']);

    $log("--- Login Attempt ---");
    $log("Username entered: '" . $username . "'");
    $log("Password entered (length: " . strlen($password) . ")");

    if (empty($username) || empty($password)) {
        $log("Error: Empty username or password");
        header("Location: index.php?page=login&error=empty");
        exit();
    }

    $query_customer = "SELECT customer_id, username, email, password FROM customer WHERE username = ?";
    $stmt_customer = mysqli_prepare($conn, $query_customer);

    if ($stmt_customer) {
        mysqli_stmt_bind_param($stmt_customer, "s", $username);
        mysqli_stmt_execute($stmt_customer);
        $result_customer = mysqli_stmt_get_result($stmt_customer);

        if ($result_customer) {
            $num_rows = mysqli_num_rows($result_customer);
            $log("Number of rows found for username '" . $username . "': " . $num_rows);

            if ($num_rows == 1) {
                $row_customer = mysqli_fetch_assoc($result_customer);
                $hashed_password_from_db = $row_customer['password'];
                $username_from_db = $row_customer['username'];

                $log("Username from DB: '" . $username_from_db . "'");
                $log("Hashed password from DB: '" . $hashed_password_from_db . "'");

                //  **Critical Debugging: Character-by-Character Comparison**
                $log("Username (entered) length: " . strlen($username));
                $log("Username (from DB) length: " . strlen($username_from_db));
                if (strlen($username) == strlen($username_from_db)) {
                    $log("Username lengths match.");
                    for ($i = 0; $i < strlen($username); $i++) {
                        if ($username[$i] != $username_from_db[$i]) {
                            $log("Username mismatch at position " . $i . ": '" . $username[$i] . "' vs '" . $username_from_db[$i] . "'");
                        }
                    }
                } else {
                    $log("Username lengths DO NOT match.");
                }

                if (password_verify($password, $hashed_password_from_db)) {
                    $log("Password verification successful for user: " . $username);
                    $_SESSION['loggedin'] = true;
                    $_SESSION['user_id'] = $row_customer['customer_id'];
                    $_SESSION['user_email'] = $row_customer['email'];
                    $_SESSION['user_name'] = $row_customer['username'];
                    $_SESSION['is_admin'] = false;
                    header("Location: dashboard.php");
                    exit();
                } else {
                    $log("Error: Password verification FAILED for user: " . $username);
                    header("Location: index.php?page=login&error=incorrect");
                    exit();
                }
            } else {
                $log("Error: User '" . $username . "' not found or multiple users found.");
                header("Location: index.php?page=login&error=incorrect");
                exit();
            }
        } else {
            $log("Error fetching results: " . mysqli_error($conn));
            header("Location: index.php?page=login&error=incorrect");
            exit();
        }
        mysqli_stmt_close($stmt_customer);
    } else {
        $log("Error preparing statement: " . mysqli_error($conn));
        header("Location: index.php?page=login&error=incorrect");
        exit();
    }
    mysqli_close($conn);
} else {
    $log("Error: Invalid request method");
    header("Location: index.php?page=login");
    exit();
}
?>