<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'connection.php';

$error = '';
$services = [];
$durations = [];
$timeSlots = [];
$priceData = [];

// Fetch unique service names
$sql = "SELECT DISTINCT service_name FROM service";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row['service_name'];
    }
}

// Fetch unique time slots
$sqlTime = "SELECT DISTINCT timeSlot FROM service";
$resultTime = $conn->query($sqlTime);
if ($resultTime) {
    while ($row = $resultTime->fetch_assoc()) {
        $timeSlots[] = $row['timeSlot'];
    }
}

// Fetch unique durations
$sqlDur = "SELECT DISTINCT duration FROM service";
$resultDur = $conn->query($sqlDur);
if ($resultDur) {
    while ($row = $resultDur->fetch_assoc()) {
        $durations[] = $row['duration'];
    }
}

// Fetch price data
$sqlPrice = "SELECT service_name, timeSlot, duration, price FROM service";
$resultPrice = $conn->query($sqlPrice);
if ($resultPrice) {
    while ($row = $resultPrice->fetch_assoc()) {
        $service = trim($row['service_name']);
        $timeSlot = trim($row['timeSlot']);
        $duration = trim($row['duration']);
        $priceData[$service][$timeSlot][$duration] = floatval($row['price']);
    }
}

// Handle booking
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $service_name = trim($_POST['service_name'] ?? '');
    $booking_date_input = trim($_POST['date'] ?? '');
    $timeSlot = trim($_POST['time_slot'] ?? '');
    $duration = trim($_POST['duration'] ?? '');

    if (!$service_name || !$booking_date_input || !$timeSlot || !$duration) {
        $error = "Please fill in all fields.";
    } else {
        $customer_id = $_SESSION['customer_id'] ?? 0;
        if ($customer_id == 0) {
            $error = "You must be logged in.";
        } else {
            // Get price
            $stmtPrice = $conn->prepare("SELECT price FROM service WHERE service_name = ? AND timeSlot = ? AND duration = ? LIMIT 1");
            $stmtPrice->bind_param("sss", $service_name, $timeSlot, $duration);
            $stmtPrice->execute();
            $resultPrice = $stmtPrice->get_result();

            if ($resultPrice && $resultPrice->num_rows === 1) {
                $priceRow = $resultPrice->fetch_assoc();
                $price = $priceRow['price'];
                $stmtPrice->close();

                // Combine date + timeslot for booking_date (store as plain date + slot text)
                $booking_date = $booking_date_input . " " . $timeSlot;

                // Prevent duplicate
                $stmtCheck = $conn->prepare("SELECT COUNT(*) as cnt FROM bookings WHERE customer_id = ? AND booking_date = ? AND service_name = ? AND status != 'Cancelled'");
                $stmtCheck->bind_param("iss", $customer_id, $booking_date, $service_name);
                $stmtCheck->execute();
                $resCheck = $stmtCheck->get_result()->fetch_assoc();
                $stmtCheck->close();

                if ($resCheck['cnt'] > 0) {
                    $error = "You already booked this service at that time.";
                } else {
                    $admin_id = 0;
                    $stmt = $conn->prepare("INSERT INTO bookings (booking_date, timeSlot, service_name, duration, price, status, customer_id, admin_id, created_at, updated_at)
                                            VALUES (?, ?, ?, ?, ?, 'Pending', ?, ?, NOW(), NOW())");
                    $stmt->bind_param("ssssdii", $booking_date, $timeSlot, $service_name, $duration, $price, $customer_id, $admin_id);

                    if ($stmt->execute()) {
                        echo "<script>alert('Booking successful!'); window.location.href='dashboard.php';</script>";
                        exit;
                    } else {
                        $error = "Booking failed: " . $stmt->error;
                    }
                    $stmt->close();
                }
            } else {
                $error = "No price found for this selection.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Massage Booking</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; }
        .container { max-width: 600px; margin: 40px auto; background: white; padding: 25px; border-radius: 10px; }
        label { display: block; margin-top: 15px; font-weight: bold; }
        select, input[type="date"] {
            width: 100%; padding: 10px; margin-top: 5px; border-radius: 6px; border: 1px solid #ccc;
        }
        .price { margin-top: 20px; font-size: 20px; color: #007BFF; }
        .error { color: red; margin-top: 10px; font-weight: bold; }
        button {
            margin-top: 20px; padding: 12px 20px; background-color: #28a745;
            border: none; color: white; font-weight: bold; border-radius: 6px; cursor: pointer;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Massage Booking Form</h2>
    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST">
        <label for="service_name">Massage Type:</label>
        <select name="service_name" id="service_name" required>
            <option value="" disabled selected>-- Select Massage Type --</option>
            <?php foreach ($services as $service): ?>
                <option value="<?= htmlspecialchars($service) ?>" <?= (isset($_POST['service_name']) && $_POST['service_name'] === $service) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($service) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="date">Booking Date:</label>
        <input type="date" name="date" required min="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($_POST['date'] ?? '') ?>">

        <label for="time_slot">Time Slot:</label>
        <select name="time_slot" id="time_slot" required>
            <option value="" disabled selected>-- Select Time Slot --</option>
            <?php foreach ($timeSlots as $slot): ?>
                <option value="<?= htmlspecialchars($slot) ?>" <?= (isset($_POST['time_slot']) && $_POST['time_slot'] === $slot) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($slot) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="duration">Duration:</label>
        <select name="duration" id="duration" required>
            <option value="" disabled selected>-- Select Duration --</option>
            <?php foreach ($durations as $dur): ?>
                <option value="<?= htmlspecialchars($dur) ?>" <?= (isset($_POST['duration']) && $_POST['duration'] === $dur) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($dur) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <p class="price">Price: ₱<span id="price">0</span></p>

        <button type="submit">Book Now</button>
    </form>
</div>

<script>
    const priceData = <?= json_encode($priceData); ?>;

    function updatePrice() {
        const service = document.getElementById('service_name').value;
        const timeSlot = document.getElementById('time_slot').value;
        const duration = document.getElementById('duration').value;
        const priceSpan = document.getElementById('price');

        if (priceData[service] && priceData[service][timeSlot] && priceData[service][timeSlot][duration]) {
            priceSpan.textContent = priceData[service][timeSlot][duration].toFixed(2);
        } else {
            priceSpan.textContent = "0";
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        updatePrice();
        document.getElementById('service_name').addEventListener('change', updatePrice);
        document.getElementById('time_slot').addEventListener('change', updatePrice);
        document.getElementById('duration').addEventListener('change', updatePrice);
    });
</script>
</body>
</html>
