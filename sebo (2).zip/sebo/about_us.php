<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Sebo Massage</title>
    <link href="styles.css" rel="stylesheet"> 
</head>
<body>

    <div class="about-us-container">
        <h1>About Sebo Massage</h1>

        <div class="about-us-content">
            <p>
                Welcome to Sebo Massage, where we are dedicated to providing an unparalleled experience 
                in relaxation and rejuvenation. Our team of skilled therapists is committed to your well-being, 
                ensuring that every visit leaves you feeling refreshed and revitalized.
            </p>

            <p>
                Sebo Massage is one of the fast-growing franchise networks in the Philippines. 
                At Sebo Massage, we are dedicated to providing top-tier massage services. 
                Our commitment to quality and customer satisfaction has made us a trusted name 
                in the wellness industry.
            </p>

            <p>
                We offer a variety of massage therapies tailored to meet your individual needs. 
                Whether you seek relief from muscle tension, stress reduction, or a moment of tranquility, 
                Sebo Massage is your haven.
            </p>
        </div>
    </div>

</body>
</html>