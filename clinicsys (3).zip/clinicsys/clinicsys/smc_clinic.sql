-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2025 at 09:45 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smc_clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `id_number` char(8) NOT NULL,
  `firstName` varchar(100) NOT NULL,
  `middleName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `Course` varchar(6) DEFAULT NULL,
  `yearLevel` int(1) DEFAULT NULL,
  `position` varchar(20) DEFAULT NULL,
  `Dept` varchar(20) DEFAULT NULL,
  `contact_number` varchar(11) NOT NULL,
  `password` varchar(16) NOT NULL,
  `role` enum('student','staff') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `id_number`, `firstName`, `middleName`, `lastName`, `email`, `Course`, `yearLevel`, `position`, `Dept`, `contact_number`, `password`, `role`) VALUES
(1, 'C20-0082', 'John', 'Del Pillar', 'Doe', 'johndelpillar.doe@example.com', 'BSIT', 3, '', 'CCS', '0987654321', '1234', 'student'),
(2, 'C21-3482', 'Marina', 'Batumbakal', 'Summers', 'marinabatumbakal.summers@my.smciligan.edu.ph', 'BSHM', 4, '', 'CHTM', '09557826735', 'alammoyanmarina', 'student'),
(3, 'C24-1198', 'Ensyr John', 'Liberty', 'Manalo', 'esnyrjohnliberty.manalo@my.smciligan.edu.ph', 'BSCS', 1, '', 'CCS', '0926741850', '0123456789', 'student'),
(4, 'C20-5674', 'Loren', 'Ipsum', 'Dolor', 'lorenipsum.dolor@my.smciligan.edu.ph', 'BAEL', 2, '', 'CASS', '09553205105', 'DontH@t3mh13', 'student'),
(5, 'C25-0039', 'Miss', 'Jade', 'So', 'missjade.so@my.smciligan.edu.ph', 'BSN', 4, '', 'CON', '09918261391', 'weareonewithin', 'student'),
(6, 'C22-8401', 'Raiden', 'Marie', 'Shogun', 'raidenmarie.shogun@my.smciligan.edu.ph', 'BSECE', 4, '', 'COE', '09268021580', 'September12021', 'student'),
(7, 'S24-0593', 'Ru', 'De Guzman', 'Paul', 'rudeguzman.paul@my.smciligan.edu.ph', '', 0, 'Dean', 'CHTM', '09556565332', '12312023', 'staff'),
(8, 'S22-4857', 'Ada', 'Fontaine', 'Lovelace', 'adafontaine.lovelace@my.smciligan.edu.ph', '', 0, 'Dean', 'CCS', '09754337912', 'Womanispower1815', 'staff'),
(9, 'S21-7624', 'William Jones', 'Dumbledore', 'Shakespeare', 'williamjonesdumbledore.shakespeare@my.smciligan.edu.ph', '', 0, 'Faculty', 'CASS', '09715521904', 'April_23', 'staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `id_number` (`id_number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
