
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySMC Higher Education</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%; 
            overflow: hidden;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            text-align: center;
        }
        .header {
            font-family: "Brush Script MT", cursive;
            background-color: #4e94fe;
            padding: 10px 20px;
            color: white;
            font-size: 35px;
            font-weight: bold;
            text-align: left;
            max-width: 100%;
            box-sizing: border-box;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 350px;
            box-sizing: border-box;
            position: absolute;
            top: 20%;
            left: 50%;
            transform: translateX(-50%);
        }
        .card img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .title {
            position: absolute;
            top: 7%;
            left: 42%;
            transform: translateX(-50%);
            color: white;
            font-size: 35px;
            font-weight: bold;
            text-align: left;
        }
        .buttons a {
            display: block;
            margin: 3px 0;
            padding: 10px;
            background: #4e94fe;
            color: white;
            text-decoration: none;
            border-radius: 3px;
            text-align: left;
            font-size: 16px;
        }
        .buttons a:hover {
            background: #a8ccf1;
        }
        .content{
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="header">SMC Clinic</div>
    <div class="container">
        <div class="card">
            <img src="smcfront.jpg" alt="SMC Building">
            <div class="title">HIGHER <br>EDUCATION <br>DEPARTMENT</div>
            <div class="buttons">
                <a href="Loginpage.php">College <br>Graduate School <br>Nurse <br> Click to Login</a>
            </div>
        </div>
    </div>
    <script>
    </script>
</body>
</html>
