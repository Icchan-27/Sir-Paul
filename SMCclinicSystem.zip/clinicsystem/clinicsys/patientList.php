<?php
include 'connect.php';

$success_message = '';
if (isset($_GET['success']) && $_GET['success'] == 1) {
    $success_message = 'Record successfully added!';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Patient List</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f2f2f2;
    }
    .sidebar {
      width: 200px;
      height: 100vh;
      background-color: #f5f5f5;
      position: fixed;
      left: 0;
      top: 0;
      padding: 20px;
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }
    .sidebar h2 {
      font-size: 18px;
      color: #333;
      margin-bottom: 20px;
    }
    .sidebar a {
      display: block;
      text-decoration: none;
      color: #333;
      padding: 10px;
      margin-bottom: 5px;
      border-radius: 5px;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background-color: #2c7df7;
      color: white;
    }
    .header {
      background-color: #2c7df7;
      color: white;
      padding: 15px;
      font-size: 20px;
      position: fixed;
      left: 0;
      top: 0;
      width: 100%;
      z-index: 1;
    }
    .logout-link {
      color: white;
      text-decoration: none;
      position: absolute;
      right: 50px;
      top: 15px;
      font-size: 15px;
      background-color: #1f5edb;
      padding: 5px 10px;
      border-radius: 5px;
      transition: background 0.3s ease;
    }
    .main-content {
      margin-left: 220px;
      padding: 80px 20px 20px 20px;
    }
    .tabs {
      display: flex;
      border-bottom: 2px solid #2c7df7;
    }
    .tab {
      padding: 10px 20px;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
      color: #333;
    }
    .tab:hover,
    .tab.active {
      background-color: #2c7df7;
      color: white;
      border-radius: 5px 5px 0 0;
    }
    .content {
      background: white;
      padding: 20px;
      border-radius: 5px;
      margin-top: -2px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #2c7df7;
      color: white;
    }
    .patient-name-btn {
      background-color: #2c7df7;
      color: white;
      border: none;
      padding: 5px 10px;
      border-radius: 5px;
      cursor: pointer;
    }
    .patient-name-btn:hover {
      background-color: #1f5edb;
    }
    .modal {
      display: none;
      position: fixed;
      z-index: 9999;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
      background-color: white;
      margin: 10% auto;
      padding: 20px;
      border-radius: 10px;
      width: 400px;
      max-height: 70%;
      overflow-y: auto;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
      position: relative;
    }
    .close-btn {
      position: absolute;
      top: 10px;
      right: 15px;
      font-size: 20px;
      color: #333;
      cursor: pointer;
    }
  </style>
  <script>
    function showTab(event, tabId) {
      document.getElementById('patient-record-tab').style.display = 'none';
      document.getElementById(tabId).style.display = 'block';
      var tabs = document.getElementsByClassName('tab');
      for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active');
      }
      event.target.classList.add('active');
    }

    function openModal(patientId) {
      fetch('fetchPatientDetails.php?id=' + patientId)
        .then(response => response.text())
        .then(data => {
          document.getElementById('patient-details').innerHTML = data;
          document.getElementById('patient-modal').style.display = 'block';
        });
    }

    function closeModal() {
      document.getElementById('patient-modal').style.display = 'none';
    }

    window.onload = function() {
      document.querySelector('.tab').click();
    };
  </script>
</head>
<body>

<div class="sidebar">
  <h2>SMC Clinic</h2>
  <a href="nurseDashBoard.php">Appointments</a>
  <a href="nurseClinic.php">Clinic</a>
  <a href="nurseInventory.php">Inventory</a>
  <a href="patientList.php" class="active">Patient List</a>
</div>

<div class="header">
  SMC Clinic - Patient List
  <a href="logout.php" class="logout-link">Log Out</a>
</div>

<div class="main-content">
<?php if (!empty($success_message)): ?>
  <div style="background-color: #d4edda; color: #155724; padding: 10px; margin-bottom: 20px; border: 1px solid #c3e6cb; border-radius: 5px;">
    <?php echo htmlspecialchars($success_message); ?>
  </div>
<?php endif; ?>
  <div class="tabs">
    <div class="tab active" onclick="showTab(event, 'patient-record-tab')">Patient Record</div>
  </div>

  <div class="content" id="patient-record-tab">
    <table>
      <thead>
        <tr>
          <th>Patient Name</th>
          <th>Patient ID</th>
          <th>Email</th>
          <th>Contact_Number</th>
          <th>Role</th>
        </tr>
      </thead>
      <tbody id="patient-table">
      <?php
      $query = "SELECT * FROM patient";
      $result = $conn->query($query);
      while ($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td><button class='patient-name-btn' onclick=\"openModal('" . $row['patient_id'] . "')\">" . htmlspecialchars($row['firstName'] . ' ' . $row['lastName']) . "</button></td>";
          echo "<td>" . htmlspecialchars($row['id_number']) . "</td>";
          echo "<td>" . htmlspecialchars($row['email']) . "</td>";
          echo "<td>" . htmlspecialchars($row['contact_number']) . "</td>";
          echo "<td>" . htmlspecialchars($row['role']) . "</td>";
          echo "</tr>";
      }
      ?>
      </tbody>
    </table>
  </div>
</div>

<div id="patient-modal" class="modal">
  <div class="modal-content">
    <span class="close-btn" onclick="closeModal()">&times;</span>
    <h3 id="modal-title">Patient Details</h3>
    <div id="patient-details"></div>
  </div>
</div>

</body>
</html>
