-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2025 at 06:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smc_clinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `nurse_id` int(11) DEFAULT NULL,
  `Reason` text DEFAULT NULL,
  `appointmentDate` date NOT NULL,
  `appointmentTime` time NOT NULL,
  `remarks` text NOT NULL,
  `Status` enum('Pending','Accepted','Rejected','Done') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `patient_id`, `nurse_id`, `Reason`, `appointmentDate`, `appointmentTime`, `remarks`, `Status`) VALUES
(3, 8, 4, 'Bugs on my code', '2025-05-19', '11:35:00', 'Not vacant', 'Rejected'),
(4, 8, 4, 'Signature for sick leave', '2025-05-23', '10:30:00', 'I gotcha Ma\'am', 'Accepted'),
(5, 9, 4, 'Expectation is the root of all heartache', '2025-05-22', '11:00:00', 'Be mindful of the time, sire.', 'Accepted'),
(6, 5, 4, 'I want to see the therapist', '2025-05-26', '11:40:00', 'She also wants to see you, dear.', 'Accepted'),
(7, 9, 4, 'Life\'s short, so do me', '2025-05-21', '11:43:00', 'So is my patience also', 'Rejected'),
(8, 3, 4, 'Afternoon coffee?', '2025-05-31', '15:50:00', 'Large nutella cream cheese with oreo bits ', 'Accepted'),
(10, 1, 4, 'Clearance po ma\'am', '2025-05-24', '16:30:00', 'Too early for a clearance, are you even enrolled?', 'Rejected'),
(11, 1, 4, 'Check-up', '2025-05-26', '10:30:00', 'I have an emergency meeting, appoint another time. TY', 'Done'),
(12, 4, 4, 'Why do people only see me as a filler?', '2025-05-26', '11:00:00', 'Cheer up dear', 'Accepted'),
(13, 6, 4, 'Visitation', '2025-05-27', '10:51:00', 'Does the clinic look like a tourist spot?', 'Rejected'),
(14, 6, 4, 'Will you check my burnt hand?', '2025-05-31', '14:00:00', 'Ohhhhh goddd, how did ya get thattt?', 'Accepted'),
(15, 3, 4, 'BMI Check', '2025-05-21', '10:00:00', 'You\'re very lateee!!!!', 'Done');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_status`
--

CREATE TABLE `clinic_status` (
  `id` int(11) NOT NULL,
  `status` enum('open','closed') NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clinic_status`
--

INSERT INTO `clinic_status` (`id`, `status`, `updated_at`) VALUES
(1, 'open', '2025-05-18 15:35:42');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `inventory_id` int(11) NOT NULL,
  `medicine_name` varchar(55) NOT NULL,
  `stockremaining` int(255) NOT NULL,
  `totalstock` int(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `medicine_name`, `stockremaining`, `totalstock`, `status`) VALUES
(8, 'Biogesic', 27, 30, 'Available'),
(9, 'Mefenamic', 24, 25, 'Available'),
(10, 'Loperamide', 0, 2, 'Not Available'),
(11, 'Band Aid', 76, 80, 'Available'),
(12, 'Bioflu', 24, 25, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `record_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `record_date` date DEFAULT NULL,
  `medicine_name` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `reason` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`record_id`, `patient_id`, `inventory_id`, `record_date`, `medicine_name`, `quantity`, `reason`) VALUES
(10, 9, 10, '2025-05-19', 'Loperamide', 1, 'Diarrhea'),
(11, 6, 11, '2025-05-16', 'Band Aid', 2, 'Blisters'),
(12, 2, 12, '2025-04-28', 'Bioflu', 1, 'Severe Headache'),
(14, 6, 10, '2025-05-14', 'Loperamide', 1, 'Diarrhea'),
(16, 1, 8, '2025-05-19', 'Biogesic', 2, 'Fever'),
(17, 1, 8, '2025-05-20', 'Biogesic', 1, 'Fever'),
(18, 3, 9, '2025-05-16', 'Mefenamic', 1, 'Toothache'),
(19, 3, 11, '2025-05-02', 'Band Aid', 2, 'Injury');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`inventory_id`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `fk_inventory_id` (`inventory_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `inventory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `records`
--
ALTER TABLE `records`
  ADD CONSTRAINT `fk_inventory_id` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
