<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySMC Login</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100%; 
            overflow: hidden;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            text-align: center;
        }
        .header {
            font-family: "Brush Script MT", cursive;
            background-color: #4e94fe;
            padding: 10px 20px;
            color: white;
            font-size: 35px;
            font-weight: bold;
            text-align: left;
            max-width: 100%;
            box-sizing: border-box;
        }
        .container {
            display: flex;
            height: calc(100vh - 50px);
            flex-wrap: wrap;
        }
        .left-panel {
            width: 60%;
            background-color: #e6e6e6;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 36px;
            font-weight: bold;
            text-align: center;
        }
        .right-panel {
            width: 40%;
            display: flex;
            justify-content: center;
            align-items: center;
            background: white;
        }
        .login-box {
            width: 300px;
            text-align: left;
        }
        h2 {
            color: #2c7df7;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #2c7df7;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 15px;
        }
        button:hover {
            background: #1b5fcc;
        }
        .Register {
            display: block;
            text-decoration: none;
            color: #2c7df7;
            font-weight: bold;
            margin-top: 10px;
        }
        .Register:hover {
            text-decoration: underline;
        }
        .back-link {
            display: block;
            text-decoration: none;
            color: #2c7df7;
            font-weight: bold;
            margin-top: 10px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .error-message {
            color: rgb(142, 27, 27);
            padding: 10px;
            font-size: 14px;
            text-align: left;
            display: none;
        }
        .left-panel img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="header">SMC Clinic</div>
    <div class="container">
        <div class="left-panel">
            <img src="gawasclinic.jpeg" alt="Gawas Clinic Image">
        </div>
        <div class="right-panel">
            <div class="login-box">
            <h2>Login</h2>
                <div id="error-message" class="error-message"></div>
                <form method="POST" action="login.php">
                    <input type="text" id="id_number" name="id_number" placeholder="ID Number" required>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                    <button type="submit">Login</button>
                </form>
                <a href="smcClinic.php" class="back-link">Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
