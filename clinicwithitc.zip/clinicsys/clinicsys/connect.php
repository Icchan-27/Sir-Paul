<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname1 = "smc_clinic";

$conn1 = new mysqli($servername, $username, $password, $dbname1);
if ($conn1->connect_error) {
    die("Connection failed: " . $conn1->connect_error);
}

$dbname2 = "smcinfosys";
$conn2 = new mysqli($servername, $username, $password, $dbname2);
if ($conn2->connect_error) {
    die("Connection failed: " . $conn2->connect_error);
}
?>