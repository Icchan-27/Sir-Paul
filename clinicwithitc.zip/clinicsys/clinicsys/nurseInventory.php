
<?php
include 'connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>SMC Clinic Dashboard</title>
<style>
    body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    }
    .sidebar {
        width: 200px;
        height: 100vh;
        background-color: #f5f5f5;
        position: fixed;
        left: 0;
        top: 0;
        padding: 20px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }
    .sidebar h2 {
        font-size: 18px;
        color: #333;
        margin-bottom: 20px;
    }
    .sidebar a {
        display: block;
        text-decoration: none;
        color: #333;
        padding: 10px;
        margin-bottom: 5px;
        border-radius: 5px;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: #2c7df7;
        color: white;
    }
    .header {
        background-color: #2c7df7;
        color: white;
        padding: 15px;
        font-size: 20px;
        position: fixed;
        left: 0;
        top: 0;
        width: 100%;
        z-index: 1;
    }
    .logout-link {
        color: white;
        text-decoration: none;
        position: absolute;
        right: 50px;
        top: 15px;
        font-size: 15px;
        background-color: #1f5edb;
        padding: 5px 10px;
        border-radius: 5px;
        transition: background 0.3s ease;
    }
    .main-content {
        margin-left: 220px;
        padding: 100px 20px 20px 20px;
    }
    .tabs {
        margin-top: 20px;
        margin-left: 15px;
        display: flex;
        border-bottom: 2px solid #2c7df7;
    }
    .tab {
        padding: 10px 20px;
        cursor: pointer;
        font-weight: bold;
        text-decoration: none;
        color: #333;
    }
    .tab:hover,
    .tab.active {
        background-color: #2c7df7;
        color: white;
        border-radius: 5px 5px 0 0;
    }
    .content {
        background: white;
        padding: 20px;
        border-radius: 5px;
        margin-top: -2px;
        margin-left: 15px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #2c7df7;
        color: white;
    }
    .add-btn {
        padding: 10px 15px;
        background-color: #1f5edb;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-bottom: 10px;
    }
    .add-btn:hover {
        background-color: #1748b5;
    }
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        justify-content: center;
        align-items: center;
        z-index: 999;
    }
    .modal-content {
        background: white;
        padding: 20px;
        border-radius: 8px;
        width: 300px;
        box-shadow: 0 0 10px rgba(0,0,0,0.3);
    }
    .modal-content h3 {
        margin-top: 0;
    }
    .modal-content label {
        display: block;
        margin-top: 10px;
    }
    .modal-content input {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        border-radius: 5px;
        border: 1px solid #ccc;
    }
    .modal-content button {
        margin-top: 15px;
        padding: 10px;
        width: 100%;
        border: none;
        border-radius: 5px;
        background-color: #2c7df7;
        color: white;
        font-weight: bold;
        cursor: pointer;
    }
    .modal-content button:hover {
        background-color: #1f5edb;
    }
</style>
</head>
<body>
<div class="sidebar">
    <h2>SMC Clinic</h2>
    <a href="nurseDashBoard.php">Appointments</a>
    <a href="nurseClinic.php">Clinic</a>
    <a href="nurseManage.php" class="active">Inventory</a>
    <a href="patientList.php">Patient List</a>
</div>

<div class="header">
    SMC Clinic Dashboard
    <a href="logout.php" class="logout-link">Log Out</a>
</div>

<div class="main-content">

    <div class="tabs">
    <a href="nurseManage.php" class="tab">Manage</a>
    <a href="nurseInventory.php" class="tab active">Inventory</a>
    </div>

    <div class="content">
        <button class="add-btn" onclick="openModal()">Add Item</button>
        <table>
            <thead>
            <tr>
                <th>Medicine</th>
                <th>Stock Remaining</th>
                <th>Total Stock</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM inventory";
                $result = $conn1->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['medicine_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['stockremaining']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['totalstock']) . "</td>";
                        $status = ($row['stockremaining'] > 0) ? 'Available' : 'Not Available';
                        echo "<td>" . $status . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No inventory found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal" id="medicineModal">
    <div class="modal-content">
        <h3>Add Medicine</h3>
        <form action="addMedicine.php" method="POST">
            <label>Medicine Name</label>
            <input type="text" name="medicine_name" required />
            <label>Quantity</label>
            <input type="number" name="quantity" min="1" required />
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById("medicineModal").style.display = "flex";
}
function closeModal() {
    document.getElementById("medicineModal").style.display = "none";
}
window.addEventListener("click", function(e) {
    const modal = document.getElementById("medicineModal");
    if (e.target === modal) closeModal();
});
</script>
</body>
</html>