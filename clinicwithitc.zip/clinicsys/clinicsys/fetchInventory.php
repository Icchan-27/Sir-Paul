<?php
session_start();
include 'connect.php';

if (!isset($_SESSION['user']) && !isset($_SESSION['admin'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$query = "SELECT medicine_name, status FROM inventory";
$result = $conn1->query($query);

$medicines = [];

while ($row = $result->fetch_assoc()) {
    $medicines[] = $row;
}

header('Content-Type: application/json');
echo json_encode($medicines);
?>
