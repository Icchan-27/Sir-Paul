<?php

include 'connection.php';

$default_admin_name = "admin";
$default_admin_password = "admin123";

$check_query = "SELECT COUNT(*) FROM admins WHERE name = ?";
$check_stmt = mysqli_prepare($conn, $check_query);
if (!$check_stmt) {
    die("Failed to prepare check query: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($check_stmt, "s", $default_admin_name);
mysqli_stmt_execute($check_stmt);
$check_result = mysqli_stmt_get_result($check_stmt);
if (!$check_result) {
    die("Failed to get result: " . mysqli_error($conn));
}
$admin_exists = mysqli_fetch_row($check_result)[0];
mysqli_stmt_close($check_stmt);

if (!$admin_exists) {
    $hashed_password = password_hash($default_admin_password, PASSWORD_DEFAULT);

    $insert_query = "INSERT INTO admins (name, password) VALUES (?, ?)";
    $insert_stmt = mysqli_prepare($conn, $insert_query);
    if (!$insert_stmt) {
        die("Failed to prepare insert query: " . mysqli_error($conn));
    }a
    mysqli_stmt_bind_param($insert_stmt, "ss", $default_admin_name, $hashed_password);

    if (mysqli_stmt_execute($insert_stmt)) {
        echo "Default admin account created successfully.\n";
        echo "name: " . $default_admin_name . "\n";
        echo "Password: " . $default_admin_password . " (Please change this password immediately!)\n";
    } else {
        echo "Error creating admin account: " . mysqli_error($conn) . "\n";
    }
    mysqli_stmt_close($insert_stmt);
} else {
    echo "Admin account already exists.\n";
}

mysqli_close($conn);
?>