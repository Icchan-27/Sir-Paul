<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Customer Dashboard</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #4d3b21;
      color: #d4af7a;
      margin: 0;
      padding: 0;
      min-height: 100vh;
      display: flex;
    }

    .hamburger {
      position: fixed;
      top: 20px;
      left: 20px;
      font-size: 30px;
      background: none;
      border: none;
      color: white;
      cursor: pointer;
      z-index: 1001;
    }

    .sidebar {
      width: 250px;
      background-color: #a19277;
      position: fixed;
      top: 0;
      left: 0;
      height: 100%;
      overflow-x: hidden;
      transition: all 0.3s ease;
      z-index: 1000;
      padding-top: 80px;
      display: flex;
      flex-direction: column;
      align-items: stretch;
    }

    .sidebar h2 {
      color: #fff;
      font-size: 24px;
      margin-bottom: 20px;
      text-align: center;
    }

    .sidebar button {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      background: linear-gradient(135deg, #786f50, #a8976a);
      border: none;
      border-radius: 8px;
      color: white;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      margin: 8px 16px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
      gap: 12px;
      text-align: left;
      justify-content: flex-start;
    }

    .sidebar button:hover {
      background: linear-gradient(135deg, #a8976a, #786f50);
      transform: translateY(-1px);
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.25);
    }

    .sidebar button i {
      min-width: 20px;
      text-align: center;
      font-size: 18px;
    }

    #main-content {
      margin-left: 250px;
      padding: 40px;
      flex-grow: 1;
      transition: margin-left 0.3s ease;
    }

    .sidebar.active + #main-content {
      margin-left: 250px;
    }

    .content-wrapper {
      background-color: #5a4530;
      padding: 40px;
      border-radius: 20px;
      max-width: 800px;
      margin: 0 auto;
      text-align: center;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
    }

    .welcome-icons {
      margin-top: 20px;
      font-size: 30px;
      color: #d4c29a;
    }

    .error-message {
      color: red;
      margin-top: 10px;
      font-weight: bold;
    }

    .success-message {
      color: green;
      margin-top: 10px;
      font-weight: bold;
    }

    @media (max-width: 768px) {
      .sidebar {
        transform: translateX(-100%);
        width: 0;
        padding-left: 0;
      }

      .sidebar.active {
        transform: translateX(0);
        width: 250px;
        padding-left: 20px;
      }

      #main-content {
        margin-left: 0;
        padding: 20px;
      }

      .sidebar.active + #main-content {
        margin-left: 0;
      }
    }
  </style>
</head>

<body>
  <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle Sidebar">
    <i class="fas fa-bars"></i>
  </button>

  <div id="sidebar" class="sidebar">
    <h2>Sebo Massage</h2>
    <button onclick="loadContent('home.php')"><i class="fas fa-home"></i> Home</button>
    <button onclick="loadContent('service.php')"><i class="fas fa-hand-holding-heart"></i> Services</button>
    <button onclick="loadContent('customer_service.php')"><i class="fas fa-headset"></i> Customer Service</button>
    <button onclick="showLogout()"><i class="fas fa-sign-out-alt"></i> Logout</button>
  </div>

  <div id="main-content">
    <div class="content-wrapper">
      <h2><i class="fas fa-spa" style="color: #d4c29a;"></i> Welcome to Sebo Massage</h2>
      <p>Experience the perfect blend of relaxation and healing with our premium massage services.</p>
      <p>Please select an option from the navigation bar to begin your journey to wellness.</p>
      <div class="welcome-icons">
        <i class="fas fa-hand-peace"></i>
        <i class="fas fa-couch"></i>
        <i class="fas fa-leaf"></i>
      </div>
    </div>
  </div>

  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.toggle('active');
    }

    function setContent(html) {
      document.getElementById("main-content").innerHTML = `<div class="content-wrapper">${html}</div>`;
    }

    function loadContent(page) {
      fetch(page)
        .then(response => response.text())
        .then(data => {
          setContent(data);
          // Close the sidebar when new content is loaded
          document.getElementById('sidebar').classList.remove('active');
        })
        .catch(error => {
          console.error('Error loading content:', error);
          setContent('<p class="error-message">Failed to load content.</p>');
          // Also close sidebar on error to keep consistent
          document.getElementById('sidebar').classList.remove('active');
        });
    }

    function showLogout() {
      window.location.href = 'sebo_logout.php';
    }

    window.addEventListener('DOMContentLoaded', () => {
      // Initially keep sidebar closed
      document.getElementById('sidebar').classList.remove('active');
    });
  </script>
</body>
</html>
