<?php
session_start();

$conn = new mysqli("localhost", "root", "", "sebo_massage_booking_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['name']) && isset($_POST['password'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];

    $query = "SELECT admin_id, name, password FROM admins WHERE name = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        //  **Clear customer session data (VERY IMPORTANT)**
        unset($_SESSION['loggedin']);
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        unset($_SESSION['is_admin']);

        //  **Set admin-specific session data**
        $_SESSION['admin_loggedin'] = true;
        $_SESSION['admin_id'] = $admin['admin_id'];
        $_SESSION['admin_name'] = $admin['name'];

        $admin_id = $admin['admin_id'];
        $ip_address = $_SERVER['REMOTE_ADDR'];

        $log_query = "INSERT INTO admin_logins (admin_id, ip_address) VALUES (?, ?)";
        $log_stmt = $conn->prepare($log_query);
        $log_stmt->bind_param("is", $admin_id, $ip_address);
        $log_stmt->execute();

        header("Location: admin_dashboard.php");
        exit();
    } else {
        header("Location: index.php?page=login&error=incorrect");  //  Or admin login page
        exit();
    }
}
?>