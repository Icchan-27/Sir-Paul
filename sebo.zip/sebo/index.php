<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Sebo Massage Booking System</title>
    <link href="styles.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
</head>
<body>

    <button class="hamburger" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <div id="sidebar" class="sidebar">
        <button onclick="showHome()">Home</button>
        <button onclick="loadContent('customer_service.php')">Customer Service</button>
        <button onclick="loadContent('service.php')">Service</button>
        <button onclick="showLogout()">Logout</button>
    </div>

    <div id="main-content">
        <!-- Content will load here dynamically -->
    </div>

    <script src="script.js"></script>
    <script>
        // Load home content when page loads
        showHome();
    </script>
</body>
</html>
