<?php
session_start();

if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'staff'])) {
    header("Location: sebo_login.php");
    exit();
}

echo "Welcome, " . ucfirst($_SESSION['user_role']) . " " . $_SESSION['user_name'];

require_once 'connection.php';

// Fetch report data
$salesQuery = "SELECT IFNULL(SUM(price), 0) AS total_sales FROM service";
$salesResult = $conn->query($salesQuery);
$totalSales = $salesResult ? $salesResult->fetch_assoc()['total_sales'] : 0;

// Count total customers from customer table
$customersQuery = "SELECT COUNT(*) AS total_customers FROM customer";
$customersResult = $conn->query($customersQuery);
$totalCustomers = $customersResult ? $customersResult->fetch_assoc()['total_customers'] : 0;

// Count total bookings from service table
$bookingsQuery = "SELECT COUNT(*) AS total_bookings FROM service"; // all bookings
$bookingsResult = $conn->query($bookingsQuery);
$totalBookings = $bookingsResult ? $bookingsResult->fetch_assoc()['total_bookings'] : 0;

// Pending, Successful, Cancelled bookings (if you want to implement, add columns in DB and queries accordingly)
$pendingBookings = "N/A";
$successfulBookings = "N/A";
$cancelledBookings = "N/A";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Dashboard</title>
    <link href="styles.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <style>
        /* Your existing CSS styles here */
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #4d3b21;
        }

        .hamburger {
            position: fixed;
            top: 20px;
            left: 20px;
            font-size: 30px;
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            z-index: 1001;
        }

        .sidebar {
            width: 250px;
            background-color: #a19277;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            overflow-x: hidden;
            transition: all 0.3s ease;
            z-index: 1000;
            padding-top: 80px;
            display: flex;
            flex-direction: column;
            align-items: stretch;
        }

        .sidebar h2 {
            color: #fff;
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .sidebar button {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            background: linear-gradient(135deg, #786f50, #a8976a);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin: 8px -10px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            gap: 12px;
            text-align: left;
            justify-content: flex-start;
        }

        .sidebar button:hover {
            background: linear-gradient(135deg, #a8976a, #786f50);
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.25);
        }

        .sidebar button i {
            min-width: 20px;
            text-align: center;
            font-size: 18px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                width: 0;
                padding-left: 0;
            }

            .sidebar.active {
                transform: translateX(0);
                width: 250px;
                padding-left: 20px;
            }
        }

        .main-content {
            margin-left: 270px;
            padding: 20px;
            min-height: 100vh;
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 20px;
            }
        }

        .reports-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 45px;
            max-width: 900px;
            margin-left: auto;
            margin-right: 65px;
        }

        .report-card {
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 30px 20px;
            border-radius: 8px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .report-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }

        .report-card h3 {
            margin-bottom: 15px;
            font-weight: 600;
            font-size: 1.4rem;
            color: #333;
        }

        .report-card .value {
            font-size: 3rem;
            font-weight: 700;
            color: #2c3e50;
        }

        .report-card .currency {
            font-size: 1.5rem;
            vertical-align: top;
            margin-left: 6px;
            color: #27ae60;
        }

        .error-message {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>

<body>
    <!-- Sidebar Toggle Button -->
    <button class="hamburger" onclick="toggleSidebar()" aria-label="Toggle Sidebar">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <h2>Sebo Massage</h2>
        <button onclick="showReports()"><i class="fas fa-chart-bar"></i> Reports</button>
        <button onclick="loadContent('customer_bookings.php')"><i class="fas fa-calendar-check"></i> Customer Bookings</button>
        <button onclick="loadContent('feedback.php')"><i class="fas fa-comment-dots"></i> Feedback</button>
        <button onclick="window.location.href='admin_logout.php'"><i class="fas fa-sign-out-alt"></i> Logout</button>
    </div>

    <!-- Main Content -->
    <div id="main-content" class="main-content">
        <div class="reports-container">
            <div class="report-card">
                <h3>Total Sales</h3>
                <div class="value">$<?php echo number_format($totalSales, 2); ?></div>
            </div>

            <div class="report-card">
                <h3>Total Customers</h3>
                <div class="value"><?php echo $totalCustomers; ?></div>
            </div>

            <div class="report-card">
                <h3>Total Bookings</h3>
                <div class="value"><?php echo $totalBookings; ?></div>
            </div>

            <div class="report-card">
                <h3>Pending Bookings</h3>
                <div class="value"><?php echo $pendingBookings; ?></div>
            </div>

            <div class="report-card">
                <h3>Successful Bookings</h3>
                <div class="value"><?php echo $successfulBookings; ?></div>
            </div>

            <div class="report-card">
                <h3>Cancelled Bookings</h3>
                <div class="value"><?php echo $cancelledBookings; ?></div>
            </div>
        </div>
    </div>

    <script>
        const sidebar = document.getElementById("sidebar");
        const mainContent = document.getElementById("main-content");

        function toggleSidebar() {
            sidebar.classList.toggle("active");
        }

        function showReports() {
            location.reload(); // reload current page for reports
        }

        function loadContent(page) {
            fetch(page)
                .then(response => response.text())
                .then(data => {
                    mainContent.innerHTML = data;
                })
                .catch(error => {
                    console.error("Error loading content:", error);
                    mainContent.innerHTML = '<p class="error-message">Failed to load content.</p>';
                });
        }
    </script>
</body>
</html>