<?php
if (isset($_GET['error'])) {
    if ($_GET['error'] == 'incorrect') {
        echo '<div class="error-message">Incorrect username or password.</div>';
    } elseif ($_GET['error'] == 'empty') {
        echo '<div class="error-message">Please enter both username and password.</div>';
    }
}
if (isset($_GET['registration']) && $_GET['registration'] == 'success') {
    echo '<div class="success-message">Registration successful! Please log in.</div>';
}
if (isset($_GET['logout']) && $_GET['logout'] == 'success') {
    echo '<div class="success-message">You have been logged out.</div>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    <link href="styles.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        .form-group {
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-top: 5px;
        }

        .form-buttons {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            background-color: #a0522d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 0 10px;
        }

        .error-message {
            color: red;
            margin-top: 10px;
        }

        .success-message {
            color: green;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="main-content">
        <div class="content-wrapper dashboard-container">
            <div id="login-form">
                <h2>
                    <i class="fas fa-sign-in-alt" style="color: #a0522d;"></i> Log In
                </h2>
                <form action="login_process.php" method="post">
                    <div class="form-group">
                        <label for="login-name">Username:</label>
                        <input type="text" id="login-name" name="login-name" placeholder="Username" required
                            oninput="this.value = this.value.trim()">
                    </div>
                    <div class="form-group">
                        <label for="login-password">Password:</label>
                        <input type="password" id="login-password" name="login-password" placeholder="Password" required
                            oninput="this.value = this.value.trim()">
                        <p style="text-align: center; margin-top: 10px;">
                            Don't have an account?
                            <a href="#" onclick="window.location.href='index.php?page=register'">Sign Up</a>
                        </p>
                    </div>
                    <div class="form-buttons">
                        <button type="submit" class="button">
                            <i class="fas fa-sign-in-alt"></i> Log In
                        </button>
                        <button type="button" class="button" onclick="window.location.href='index.php'">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    </script>
</body>

</html> 