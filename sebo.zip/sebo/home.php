<div class="content-wrapper home-content">
    <h1><i class="fas fa-spa" style="color: #a0522d;"></i> Welcome to Sebo Massage</h1>
    <p>Experience the perfect blend of relaxation and healing with our premium massage services.</p>
    <p>Please select an option from the navigation bar to begin your journey to wellness.</p>
    <div style="margin-top: 30px;">
        <i class="fas fa-hands" style="font-size: 50px; color: #a0522d; margin: 0 15px;"></i>
        <i class="fas fa-hot-tub" style="font-size: 50px; color: #a0522d; margin: 0 15px;"></i>
        <i class="fas fa-leaf" style="font-size: 50px; color: #a0522d; margin: 0 15px;"></i>
    </div>
</div>
