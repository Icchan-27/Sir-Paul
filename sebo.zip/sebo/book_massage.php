<?php
session_start();
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        header("Location: index.php?page=login"); 
        exit();
    }

    $customer_id = $_SESSION['user_id']; 
    $service_name = $_POST['service_name'];
    $duration = $_POST['duration'];      
    $price = $_POST['price'];             

    $service_name = mysqli_real_escape_string($conn, $service_name);
    $duration = mysqli_real_escape_string($conn, $duration);
    $price = mysqli_real_escape_string($conn, $price);

    if (empty($service_name) || empty($duration) || empty($price)) {
        echo "<script>alert('Error: All fields are required.'); history.back();</script>";
        exit();
    }

    $query = "INSERT INTO service (customer_id, service_name, duration, price) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "isid", $customer_id, $service_name, $duration, $price);
        if (mysqli_stmt_execute($stmt)) {
            echo "<script>
                alert('Service booked successfully!');
                window.location.href = 'sebo_logout.php';
            </script>";
        } else {
            echo "Error booking service: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
?>
